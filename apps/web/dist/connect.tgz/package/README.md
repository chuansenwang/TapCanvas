# TapCanvas Canvas → Codex Bridge

This package connects a TapCanvas canvas to a real Codex process running on the
user's host machine. Codex is not placed in the TapCanvas Docker Compose stack.

## New-user flow

1. Open a project canvas and switch the chat execution target from **小T** to
   **Codex**.
2. If no local bridge is online, click **复制给 Codex**.
3. Paste the copied installation task into Codex while Codex is opened in the
   workspace that may be edited.
4. Codex reads the repository rules and scripts, creates the real
   `.tapcanvas/codex-workspace.json`, then runs the one-time pairing command
   included in the task.
5. Wait for Codex to report that the bridge is online. Return to the canvas,
   select the bridge/workspace, enter a product goal, and dispatch it.

The browser cannot securely start a native process that has never been
installed. The copy/paste step is therefore the one-time trust boundary. After
installation, the LaunchAgent or systemd user service stays online; selecting
**Codex** on the canvas activates the already-paired execution path without
another terminal flow.

## What the pairing command installs

- a dedicated TapCanvas API credential in
  `~/.tapcanvas/codex-bridge.json` with mode `0600`;
- the TapCanvas MCP entry in `~/.codex/config.toml`;
- the `tapcanvas-canvas-builder` Codex Skill under `~/.codex/skills`;
- the authenticated `tapcanvas` platform CLI and canonical `tapcanvas-api`
  Skill, verified against its explicit profile before the Bridge starts;
- a versioned runtime under `~/.tapcanvas/connect/<version>`;
- `com.tapcanvas.codex-bridge` as a macOS LaunchAgent, or
  `tapcanvas-codex-bridge.service` as a Linux systemd user service;
- host-only logs under `~/.tapcanvas/logs`.

Before consuming the one-time pairing code, the installer verifies the HTTPS
TapCanvas origin (HTTP is allowed only on loopback), the Codex and Node
executables, the workspace contract, required environment variables, and the
host service manager. It then starts the real Codex App Server, negotiates the
experimental protocol, and creates a read-only ephemeral thread for the
authorized workspace. This compatibility probe never starts a turn or changes
files. Unsupported platforms, invalid workspaces, and incompatible Codex
versions therefore fail before the single-use pairing code is consumed.

The persistent service receives an explicit `PATH` containing the managed
TapCanvas CLI command directory. A dispatched Codex thread can therefore use
the CLI for additional canvas reads or authorized writes without depending on
an interactive shell profile.

## TapCanvas CLI & Skill

The account center exposes **CLI & SKILL** with a connected-plug icon. Its
**通过 AI 助手安装** action opens a compact prompt that contains only the
self-hosted package URL and never contains a credential. Codex, Kimi Code,
MiniMax Agent, Trae, or another terminal-capable assistant reads this package
contract and runs the self-hosted installer; the user then confirms the browser
authorization, and the installer writes:

- the versioned `tapcanvas` runtime under `~/.tapcanvas/cli/<version>`;
- the managed command under `~/.tapcanvas/bin/tapcanvas` and a user command
  link at `~/.local/bin/tapcanvas`;
- `~/.tapcanvas/config.json` with mode `0600`, using independent `local` and
  `production` profiles;
- the canonical `tapcanvas-api` Skill under
  `~/.codex/skills/tapcanvas-api/SKILL.md`.

The short prompt shown to the user has this shape:

```text
请帮我安装 TapCanvas 官方 CLI 和 tapcanvas-api Skill：https://your-tapcanvas-domain/connect.tgz?v=<package-version>
```

The package contract resolves that request to this underlying command:

```bash
npx -y 'https://your-tapcanvas-domain/connect.tgz?v=<package-version>' install-cli \
  --base-url https://your-tapcanvas-domain
```

The package opens `/connect/cli` and receives the dedicated API key only over
the loopback callback. The key is never present in the account-center prompt.
Before browser authorization, the installer checks every managed destination
and refuses to overwrite an existing config, command, or Skill that does not
belong to a recorded TapCanvas CLI installation.
The account-center prompt includes the current package version as a query value
so `npx` cannot reuse an older URL-cached tarball during an upgrade.

The installer records the authorized origin in its matching profile. Add or
replace another environment by piping its key through stdin; keys never need to
appear in a command argument or repository file:

```bash
printf '%s' "$TAPCANVAS_LOCAL_API_KEY" | tapcanvas config set \
  --profile local --api-base-url http://localhost:8788 --api-key-stdin
printf '%s' "$TAPCANVAS_PRODUCTION_API_KEY" | tapcanvas config set \
  --profile production --api-base-url https://tc.tanvas.cn --api-key-stdin
tapcanvas config list
```

Every network command requires `--profile local|production`, or an explicitly
set `TAPCANVAS_PROFILE`. `local` accepts loopback only; `production` requires
non-loopback HTTPS. There is no default profile, URL inference during calls, or
automatic environment switch. Version-1 single-environment config is rejected
and must be rebuilt explicitly.
The profile also fixes reverse-proxy routing deterministically: protected
production endpoints use `/api/*`, public production endpoints remain under
root `/public/*`, and local endpoints connect directly to the backend root.
The CLI never probes one prefix and retries another after a 404 or HTML page.

After installation, verify the real command and selected API credential:

```bash
tapcanvas doctor --profile production --json
tapcanvas --version
```

Platform commands use JSON output; event subscriptions use NDJSON:

```bash
tapcanvas projects list --profile production
tapcanvas flows list --profile production --project-id <project-id>
tapcanvas flows get --profile production --flow-id <flow-id>
tapcanvas api call --profile production --endpoint flowVersions --flowId <flow-id>
# 仅在用户明确授权覆盖后，使用上一步返回的精确不可变版本 ID：
tapcanvas api call --profile production --endpoint flowRollback \
  --flowId <flow-id> --payload '{"versionId":"<version-id>"}'
tapcanvas tools list --profile production --project-id <project-id> \
  --chapter-id <chapter-id>
tapcanvas tools schema --profile production --name <tool-name> \
  --project-id <project-id> --chapter-id <chapter-id>
tapcanvas tools call --profile production --name <tool-name> \
  --project-id <project-id> --chapter-id <chapter-id> --input '{"key":"value"}'
tapcanvas events subscribe --profile production --flow-id <flow-id> --timeout 120
```

### Agent API 接入

`Agent API 接入` is the asynchronous finished-video facade for applications
that want to hand a user request plus image/video inputs to 小T without first
creating a TapCanvas project. The submit call returns a stable job immediately;
the platform follows the caller's normal owner/team project scope and creates a
dedicated flow when those IDs are omitted, hosts every external media input in
TapCanvas object storage, and then
runs the existing agents-cli video workflow against that real canvas scope.

```bash
tapcanvas agent-api submit \
  --profile production \
  --prompt '把产品图片和演示视频加工成 15 秒竖屏广告' \
  --model-key '<enabled-language-model-key>' \
  --image-url 'https://input.example/product.png' \
  --video-url 'https://input.example/demo.mp4' \
  --video-resolution '480p' \
  --target-duration-seconds '15' \
  --aspect-ratio '9:16'
```

Both URL flags may be repeated. Previously uploaded assets can be supplied with
repeated `--image-asset-id` and `--video-asset-id`; `--media-json` accepts the
full typed media array when roles, names, or notes are required. To reuse an
existing canvas, pass `--project-id` and `--flow-id` together. Passing neither
is the normal isolated-job path. `--video-resolution`, `--aspect-ratio`, and
`--target-duration-seconds` freeze the requested production specification into
the stable job; omitted resolution and aspect values are resolved from the
account's most recent generation preferences at submission time. The target is
the final assembled video duration and accepts 1–180 seconds. Longer results are
formed from clips that each obey the selected video model's live single-clip
duration options; 180 seconds is never sent as an unsupported provider clip.

The submit response has `object: "agent.video.job"`, a stable `id`, the resolved
`projectId` and `flowId`, and `status: "queued"`. Poll or wait using that exact
job identity:

```bash
tapcanvas agent-api status --profile production --job-id '<job-id>'
tapcanvas agent-api wait --profile production --job-id '<job-id>' --interval 5 --timeout 1800
```

`queued` and `running` are receipts, not video delivery. `needs_input` returns
structured questions and stops the CLI wait with a non-zero exit status.
`failed` preserves the server error. Only `succeeded` includes the verified,
hosted `result.videoUrl`; text responses, tool acceptance, intermediate clips,
and temporary URLs never satisfy the job.

The same contract can be called directly without the CLI. Keep the returned
`id`; omitting `projectId` asks TapCanvas to create the project scope:

```bash
curl -X POST 'https://your-tapcanvas-domain/public/agent-api/video-jobs' \
  -H 'Authorization: Bearer '"$TAPCANVAS_API_KEY" \
  -H 'Content-Type: application/json' \
  --data '{
    "prompt":"把产品图片和演示视频加工成 15 秒竖屏广告",
    "modelKey":"<enabled-language-model-key>",
    "targetDurationSeconds":15,
    "aspectRatio":"9:16",
    "media":[
      {"type":"image","sourceUrl":"https://input.example/product.png","role":"product"},
      {"type":"video","sourceUrl":"https://input.example/demo.mp4","role":"source"}
    ]
  }'

curl 'https://your-tapcanvas-domain/public/agent-api/video-jobs/<job-id>' \
  -H 'Authorization: Bearer '"$TAPCANVAS_API_KEY"
```

Tool scope flags are `[--flow-id | --chapter-id] [--book-id] [--node-id]
[--execution-id]`; only `--project-id` is universally required. Canonical chapter
IDs deterministically provide their book scope. `tools list`, `tools schema`, and
`tools call` use the same user identity and registered TapCanvas tool bridge as
the Web UI, including project ownership, billing, idempotency, and destructive
operation checks. They do not expose administrator, internal recovery, or host
operations. The Skill must list the current capability surface and load the
dynamic schema before it calls a business tool; it must not infer parameters
from a previous run or a local template.

## Workspace contract

Codex creates this file from repository facts; the canvas does not guess build
commands:

```json
{
  "version": 1,
  "id": "stable-workspace-id",
  "label": "Product name",
  "commands": {
    "install": ["pnpm", "install", "--frozen-lockfile"],
    "test": ["pnpm", "test", "--run"],
    "build": ["pnpm", "build"],
    "preview": ["pnpm", "preview", "--host", "0.0.0.0", "--port", "4173"]
  },
  "outputDirectory": "dist",
  "previewPort": 4173,
  "previewReadyPath": "/",
  "previewReadyTimeoutMs": 60000,
  "remoteBuild": {
    "provider": "vercel-sandbox",
    "runtime": "node24",
    "timeoutMs": 1800000,
    "vcpus": 2
  },
  "environmentVariables": []
}
```

Every command is an argv array and is executed without a shell. `outputDirectory`
must stay inside the workspace. `environmentVariables` contains names only; the
host reads their values and sends them inside an encrypted, task-scoped build
envelope. A local Docker fallback is optional and is accepted only with a pinned
`image@sha256:...` plus explicit resource limits.

## Execution boundary

The host bridge has one worker lock and claims one Redis-leased task at a time.
It asks native `codex app-server --listen stdio://` to edit only the authorized
workspace. Codex itself does not install dependencies, build, test, preview,
deploy, or run Docker.

The workspace boundary is the validated absolute path plus
`.tapcanvas/codex-workspace.json`; Git is not a prerequisite. If a repository
has Git metadata, Codex may use read-only inspection when repository rules
permit it, but the bridge never requires a commit, branch, or remote. Source
archives explicitly exclude `.git`, dependency directories, build outputs, and
common secret files.

## Canvas context and continuous conversation

Task protocol v2 keeps canvas facts and conversation continuity separate:

- Before dispatch, the browser runs the existing project/chapter persistence
  barrier and refuses to continue if saving fails, edits remain dirty, or the
  persisted revision cannot be verified. It then sends only the structural
  scope (`projectId`, one of `flowId` or `chapterId`, the confirmed revision,
  and selected node IDs).
- Hono reads the authorized persisted project and canvas, derives selected-node
  kinds server-side, and creates an immutable snapshot containing the complete
  graph, selected nodes, counts, revision, and SHA-256 fingerprint. The browser
  cannot forge node contents or kinds.
- Snapshot creation fails explicitly on a stale revision, stale selection,
  invalid graph, or a payload above the 2 MiB hard limit. It is never silently
  truncated or replaced with partial context.
- The full snapshot is stored separately from the user-visible task record and
  is released only to the leased host worker that claimed that task.

Each canvas conversation has a stable `sessionId`; every user turn is a
separate durable task linked by `parentTaskId` and `turnSequence`. The first
turn starts a persistent, non-ephemeral Codex App Server thread. A later turn
resumes the verified `threadId` only when the user, bridge, workspace, project,
flow/chapter, and latest-parent relation still match. The latest snapshot is
authoritative for current canvas state, while the resumed thread retains prior
decisions and discussion.

While a turn is still running, browser follow-ups enter a durable task-message
mailbox and the bridge forwards them with `turn/steer`. Delivery is recorded as
`queued` until App Server acceptance is confirmed, then `delivered`, `rejected`,
or `unknown`; a lost confirmation is never presented as delivered or as a
definite rejection. Once a turn is terminal, the next message creates a new
task and resumes the same Codex thread. This gives the canvas both live steering
and genuine second-turn conversation without opening a terminal again. Live
steering is limited to the same immutable flow/chapter revision and selection;
if the canvas changed, the UI waits for a new turn and supplies a new snapshot
instead of implying that the active turn saw those edits.

The App Server final response is constrained to one of four structured
outcomes:

- `workspace_changed`: real file-change evidence exists, so isolated build and
  preview verification must run;
- `needs_input`: no files changed, the task becomes `awaiting_user_input`, and
  the question appears in the same canvas chat timeline;
- `response_only`: no files changed and the response is terminally verified
  without starting a build;
- `failed`: the exact failure is recorded.

An outcome that contradicts observed file changes fails explicitly. The bridge
does not infer completion from prose.

After Codex reports actual changed files, the bridge archives the workspace and
uploads it directly to private object storage. The TapCanvas remote-builder
orchestrator passes that private tarball to Vercel Sandbox, where install, test,
build, and preview run. The TapCanvas server never mounts the workspace and
never executes those user commands.

A code/test/build failure is terminal. Only a failure classified as remote
infrastructure failure can enter `fallback_approval_required`; local Docker runs
only after the user clicks approval on the canvas. No model, provider, command,
or executor silently falls back.

Completion is verified from `expectedDelivery -> deliveryEvidence ->
deliveryVerification`. Workspace-change turns require changed files, command
exit codes, an isolated preview URL, readiness probe, and valid expiry.
Response-only and needs-input turns require a completed Codex turn, a matching
no-file-change outcome, and no hidden workspace side effect. The resulting
preview, when one exists, is opened through `/preview/:previewId`.

## CLI commands

The canvas generates the exact one-time command. Its underlying shape is:

```bash
npx -y https://your-tapcanvas-domain/connect.tgz pair \
  --base-url https://your-tapcanvas-domain \
  --pairing-code '<one-time-code>' \
  --workspace .
```

The persistent worker is normally started by the OS service:

```bash
node src/cli.mjs worker
```

## Existing MCP-client connection

The previous interactive connector remains available for Claude Code, Codex,
and Cursor:

```bash
npx -y https://your-tapcanvas-domain/connect.tgz \
  --base-url https://your-tapcanvas-domain \
  --client codex
```

This legacy command opens a loopback authorization page and configures the
selected MCP client. It is separate from the canvas-dispatched Codex worker.

## Development

```bash
node --test test/*.test.mjs
node src/cli.mjs --help
```

`TAPCANVAS_CONNECT_NO_BROWSER=1` affects loopback authorization flows, including
CLI & Skill installation. Tests can isolate installation with
`TAPCANVAS_HOME`, `CODEX_HOME`, and `TAPCANVAS_COMMAND_DIR`.
