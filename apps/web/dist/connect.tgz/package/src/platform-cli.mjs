#!/usr/bin/env node

import { spawn } from "node:child_process"
import { randomUUID } from "node:crypto"
import { promises as fs } from "node:fs"
import os from "node:os"
import path from "node:path"
import { fileURLToPath } from "node:url"
import {
  buildTapCanvasApiUrl,
  createTapCanvasConfigWithProfile,
  describeTapCanvasProfiles,
  resolveTapCanvasCredentials,
  resolveTapCanvasProfile,
} from "./platform-profile-config.mjs"
import { PLATFORM_CLI_VERSION } from "./version.mjs"

const AGENT_API_MAX_VIDEO_DURATION_SECONDS = 180

function runtimeRoot() {
  return path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..")
}

function configPath() {
  const root = process.env.TAPCANVAS_HOME
    ? path.resolve(process.env.TAPCANVAS_HOME)
    : path.join(os.homedir(), ".tapcanvas")
  return path.join(root, "config.json")
}

function optionValue(args, name) {
  const equalPrefix = `${name}=`
  const equalValue = args.find((value) => value.startsWith(equalPrefix))
  if (equalValue) return equalValue.slice(equalPrefix.length)
  const index = args.indexOf(name)
  return index >= 0 ? String(args[index + 1] || "") : ""
}

function optionValues(args, name) {
  const values = []
  const equalPrefix = `${name}=`
  for (let index = 0; index < args.length; index += 1) {
    const value = args[index]
    if (value.startsWith(equalPrefix)) {
      const equalValue = value.slice(equalPrefix.length).trim()
      if (equalValue) values.push(equalValue)
      continue
    }
    if (value !== name) continue
    const next = String(args[index + 1] || "").trim()
    if (next) values.push(next)
    index += 1
  }
  return values
}

function requiredOption(args, name) {
  const value = optionValue(args, name).trim()
  if (!value) throw new Error(`缺少 ${name}`)
  return value
}

function hasOption(args, name) {
  return args.some((value) => value === name || value.startsWith(`${name}=`))
}

function deriveBookIdFromChapterId(chapterId) {
  const normalizedChapterId = String(chapterId || "").trim()
  if (!normalizedChapterId.startsWith("book-")) return ""
  const chapterMarkerIndex = normalizedChapterId.lastIndexOf("-ch")
  if (chapterMarkerIndex <= "book-".length) return ""
  const chapterSequence = normalizedChapterId.slice(chapterMarkerIndex + 3)
  if (
    !chapterSequence ||
    Array.from(chapterSequence).some(
      (character) => character < "0" || character > "9",
    )
  ) {
    return ""
  }
  return normalizedChapterId.slice("book-".length, chapterMarkerIndex).trim()
}

function readToolScope(args) {
  const canvasProjectId = requiredOption(args, "--project-id")
  const canvasFlowId = optionValue(args, "--flow-id").trim()
  const chapterId = optionValue(args, "--chapter-id").trim()
  if (canvasFlowId && chapterId) {
    throw new Error("--flow-id 与 --chapter-id 不能同时提供")
  }
  const explicitBookId = optionValue(args, "--book-id").trim()
  const derivedBookId = deriveBookIdFromChapterId(chapterId)
  if (explicitBookId && derivedBookId && explicitBookId !== derivedBookId) {
    throw new Error("--book-id 与 --chapter-id 所指向的书籍不一致")
  }
  const bookId = explicitBookId || derivedBookId
  const canvasNodeId = optionValue(args, "--node-id").trim()
  const executionId = optionValue(args, "--execution-id").trim()
  return {
    canvasProjectId,
    ...(canvasFlowId ? { canvasFlowId } : {}),
    ...(chapterId ? { chapterId } : {}),
    ...(bookId ? { bookId } : {}),
    ...(canvasNodeId ? { canvasNodeId } : {}),
    ...(executionId ? { executionId } : {}),
  }
}

function mergeScopedToolArgs(toolArgs, scope) {
  const merged = { ...toolArgs }
  for (const [scopeField, argsField] of [
    ["bookId", "bookId"],
    ["canvasNodeId", "nodeId"],
    ["executionId", "executionId"],
  ]) {
    const scopeValue = String(scope[scopeField] || "").trim()
    if (!scopeValue) continue
    const argsValue = String(merged[argsField] || "").trim()
    if (argsValue && argsValue !== scopeValue) {
      throw new Error(`--${argsField.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`)} 与 --input.${argsField} 不一致`)
    }
    merged[argsField] = scopeValue
  }
  return merged
}

function printJson(value) {
  process.stdout.write(`${JSON.stringify(value, null, 2)}\n`)
}

function runScript(script, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [script, ...args], {
      stdio: "inherit",
      env: process.env,
    })
    child.on("error", reject)
    child.on("exit", (code, signal) => {
      if (signal) {
        reject(new Error(`TapCanvas 子进程被信号 ${signal} 终止`))
        return
      }
      resolve(Number.isInteger(code) ? code : 1)
    })
  })
}

function withConfig(args) {
  return hasOption(args, "--config")
    ? args
    : [...args, "--config", configPath()]
}

function withProfile(args, commandArgs) {
  if (hasOption(args, "--profile")) return args
  const profile = resolveTapCanvasProfile(
    { profile: optionValue(commandArgs, "--profile") },
  )
  return [...args, "--profile", profile]
}

async function readConfigDocument(file, options = {}) {
  try {
    return JSON.parse(await fs.readFile(file, "utf8"))
  } catch (error) {
    if (options.allowMissing && error && typeof error === "object" && error.code === "ENOENT") {
      return null
    }
    throw new Error(`TapCanvas CLI 配置不可读：${file}`)
  }
}

async function atomicWriteConfig(file, value) {
  await fs.mkdir(path.dirname(file), { recursive: true, mode: 0o700 })
  const temporary = `${file}.${process.pid}.${randomUUID()}.tmp`
  await fs.writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, {
    encoding: "utf8",
    mode: 0o600,
    flag: "wx",
  })
  await fs.chmod(temporary, 0o600)
  await fs.rename(temporary, file)
  await fs.chmod(file, 0o600)
}

async function readStdinText() {
  const chunks = []
  for await (const chunk of process.stdin) chunks.push(chunk)
  return Buffer.concat(chunks.map((chunk) => Buffer.from(chunk))).toString("utf8")
}

async function readPlatformConfig(args, options = {}) {
  const file = configPath()
  const document = await readConfigDocument(file)
  const profile = resolveTapCanvasProfile(
    { profile: optionValue(args, "--profile") },
  )
  return resolveTapCanvasCredentials({
    document,
    file,
    profile,
    environment: process.env,
    requireApiKey: options.requireApiKey === true,
  })
}

function authorizationHeader(config) {
  if (config.authToken) {
    return config.authToken.startsWith("Bearer ")
      ? config.authToken
      : `Bearer ${config.authToken}`
  }
  return `Bearer ${config.apiKey}`
}

async function requestPlatformJson(args, pathname, options = {}) {
  const config = await readPlatformConfig(args)
  const requestUrl = buildTapCanvasApiUrl({
    profile: config.profile,
    apiBaseUrl: config.apiBaseUrl,
    pathname,
    access: options.access === "protected" ? "protected" : "public",
  })
  const response = await fetch(requestUrl, {
    method: options.method || "GET",
    headers: {
      Authorization: authorizationHeader(config),
      Accept: "application/json",
      ...(options.body === undefined ? {} : { "Content-Type": "application/json" }),
    },
    ...(options.body === undefined ? {} : { body: JSON.stringify(options.body) }),
  })
  const responseText = await response.text()
  let payload = null
  try {
    payload = responseText ? JSON.parse(responseText) : null
  } catch {
    payload = responseText
  }
  if (!response.ok) {
    throw new Error(JSON.stringify({
      operation: options.operation || "request",
      status: response.status,
      statusText: response.statusText,
      response: payload,
    }, null, 2))
  }
  return payload
}

function buildAgentApiMedia(args) {
  const declared = []
  for (const sourceUrl of optionValues(args, "--image-url")) {
    declared.push({ type: "image", sourceUrl, role: "reference" })
  }
  for (const sourceUrl of optionValues(args, "--video-url")) {
    declared.push({ type: "video", sourceUrl, role: "source" })
  }
  for (const assetId of optionValues(args, "--image-asset-id")) {
    declared.push({ type: "image", assetId, role: "reference" })
  }
  for (const assetId of optionValues(args, "--video-asset-id")) {
    declared.push({ type: "video", assetId, role: "source" })
  }
  const mediaJson = optionValue(args, "--media-json").trim()
  if (!mediaJson) return declared
  let parsed
  try {
    parsed = JSON.parse(mediaJson)
  } catch {
    throw new Error("--media-json 必须是合法 JSON")
  }
  if (!Array.isArray(parsed)) throw new Error("--media-json 必须是 JSON 数组")
  return [...declared, ...parsed]
}

async function submitAgentApiVideo(args) {
  const projectId = optionValue(args, "--project-id").trim()
  const flowId = optionValue(args, "--flow-id").trim()
  if (flowId && !projectId) throw new Error("--flow-id 必须与 --project-id 同时提供")
  const aspectRatio = optionValue(args, "--aspect-ratio").trim()
  const videoResolution = optionValue(args, "--video-resolution").trim()
  const targetDurationSeconds = boundedPositiveIntegerOption(
    args,
    "--target-duration-seconds",
    AGENT_API_MAX_VIDEO_DURATION_SECONDS,
  )
  const projectName = optionValue(args, "--project-name").trim()
  const flowName = optionValue(args, "--flow-name").trim()
  const payload = await requestPlatformJson(args, "/public/agent-api/video-jobs", {
    method: "POST",
    operation: "agent-api.submit",
    body: {
      prompt: requiredOption(args, "--prompt"),
      modelKey: requiredOption(args, "--model-key"),
      media: buildAgentApiMedia(args),
      ...(projectId ? { projectId } : {}),
      ...(flowId ? { flowId } : {}),
      ...(videoResolution ? { videoResolution } : {}),
      ...(aspectRatio ? { aspectRatio } : {}),
      ...(targetDurationSeconds === null ? {} : { targetDurationSeconds }),
      ...(projectName ? { projectName } : {}),
      ...(flowName ? { flowName } : {}),
    },
  })
  printJson(payload)
}

async function getAgentApiVideoStatus(args, jobId) {
  return requestPlatformJson(
    args,
    `/public/agent-api/video-jobs/${encodeURIComponent(jobId)}`,
    { operation: "agent-api.status" },
  )
}

async function showAgentApiVideoStatus(args) {
  printJson(await getAgentApiVideoStatus(args, requiredOption(args, "--job-id")))
}

function positiveIntegerOption(args, name, fallback) {
  const raw = optionValue(args, name).trim()
  if (!raw) return fallback
  const value = Number(raw)
  if (!Number.isInteger(value) || value <= 0) throw new Error(`${name} 必须是正整数`)
  return value
}

function boundedPositiveIntegerOption(args, name, maximum) {
  if (!hasOption(args, name)) return null
  const value = positiveIntegerOption(args, name, null)
  if (value === null) throw new Error(`${name} 缺少数值`)
  if (value > maximum) throw new Error(`${name} 最大允许 ${maximum} 秒`)
  return value
}

async function waitForAgentApiVideo(args) {
  const jobId = requiredOption(args, "--job-id")
  const intervalSeconds = positiveIntegerOption(args, "--interval", 5)
  const timeoutSeconds = positiveIntegerOption(args, "--timeout", 1800)
  const deadline = Date.now() + timeoutSeconds * 1000
  while (true) {
    const job = await getAgentApiVideoStatus(args, jobId)
    const status = String(job?.status || "")
    if (["succeeded", "failed", "needs_input"].includes(status)) {
      printJson(job)
      if (status !== "succeeded") process.exitCode = 2
      return
    }
    if (status !== "queued" && status !== "running") {
      throw new Error(`Agent API 返回未知任务状态：${status || "<empty>"}`)
    }
    if (Date.now() >= deadline) {
      throw new Error(`等待 Agent API 任务超时：${jobId}`)
    }
    await new Promise((resolve) => setTimeout(resolve, intervalSeconds * 1000))
  }
}

function inferUploadMediaType(file, explicitContentType) {
  const normalizedContentType = String(explicitContentType || "").trim().toLowerCase()
  if (normalizedContentType.startsWith("image/")) return { mediaType: "image", contentType: normalizedContentType }
  if (normalizedContentType.startsWith("video/")) return { mediaType: "video", contentType: normalizedContentType }
  if (normalizedContentType.startsWith("audio/")) return { mediaType: "audio", contentType: normalizedContentType }
  const extension = path.extname(file).toLowerCase()
  const contentTypeByExtension = new Map([
    [".avif", "image/avif"],
    [".gif", "image/gif"],
    [".jpeg", "image/jpeg"],
    [".jpg", "image/jpeg"],
    [".png", "image/png"],
    [".webp", "image/webp"],
    [".m4v", "video/x-m4v"],
    [".mov", "video/quicktime"],
    [".mp4", "video/mp4"],
    [".webm", "video/webm"],
    [".m4a", "audio/mp4"],
    [".mp3", "audio/mpeg"],
    [".ogg", "audio/ogg"],
    [".wav", "audio/wav"],
  ])
  const contentType = contentTypeByExtension.get(extension) || ""
  if (contentType.startsWith("image/")) return { mediaType: "image", contentType }
  if (contentType.startsWith("video/")) return { mediaType: "video", contentType }
  if (contentType.startsWith("audio/")) return { mediaType: "audio", contentType }
  throw new Error(`无法从文件扩展名确定图片、视频或音频类型：${file}`)
}

async function uploadAsset(args) {
  const file = path.resolve(requiredOption(args, "--file"))
  const projectId = requiredOption(args, "--project-id")
  const stat = await fs.stat(file).catch(() => null)
  if (!stat?.isFile()) throw new Error(`上传文件不存在或不是普通文件：${file}`)
  const maxBytes = 30 * 1024 * 1024
  if (stat.size <= 0) throw new Error(`上传文件为空：${file}`)
  if (stat.size > maxBytes) throw new Error(`上传文件超过 30MB 硬上限：${file}`)

  const { mediaType, contentType } = inferUploadMediaType(file, optionValue(args, "--content-type"))
  const configuredName = optionValue(args, "--name").trim()
  const name = configuredName || path.basename(file)
  const { profile, apiBaseUrl, apiKey, authToken } = await readPlatformConfig(args)
  const query = new URLSearchParams({ name, projectId })
  const authorization = authToken
    ? (authToken.startsWith("Bearer ") ? authToken : `Bearer ${authToken}`)
    : `Bearer ${apiKey}`
  const response = await fetch(buildTapCanvasApiUrl({
    profile,
    apiBaseUrl,
    pathname: `/assets/upload?${query.toString()}`,
    access: "protected",
  }), {
    method: "POST",
    headers: {
      Authorization: authorization,
      "Content-Type": contentType,
      "X-File-Size": String(stat.size),
      "X-Tap-No-Retry": "1",
    },
    body: await fs.readFile(file),
  })
  const responseText = await response.text()
  let payload = null
  try {
    payload = responseText ? JSON.parse(responseText) : null
  } catch {
    payload = responseText
  }
  if (!response.ok) {
    throw new Error(JSON.stringify({
      operation: "assets.upload",
      status: response.status,
      statusText: response.statusText,
      response: payload,
    }, null, 2))
  }
  const assetId = typeof payload?.id === "string" ? payload.id.trim() : ""
  const assetName = typeof payload?.name === "string" ? payload.name.trim() : ""
  const storedType = typeof payload?.data?.type === "string" ? payload.data.type.trim() : ""
  const storedUrl = typeof payload?.data?.url === "string" ? payload.data.url.trim() : ""
  const storedProjectId = typeof payload?.projectId === "string" ? payload.projectId.trim() : ""
  if (!assetId || !assetName || storedType !== mediaType || !storedUrl || storedProjectId !== projectId) {
    throw new Error("上传接口成功响应缺少或返回了不一致的可执行资产事实（id/name/type/url/projectId）")
  }
  printJson({
    ok: true,
    asset: {
      assetId,
      name: assetName,
      mediaType: storedType,
      ready: true,
      projectId: storedProjectId,
      originalName: path.basename(file),
      size: stat.size,
    },
  })
}

async function runApi(args, commandArgs = args) {
  const script = path.join(
    runtimeRoot(),
    "skill",
    "tapcanvas-api",
    "scripts",
    "call.mjs",
  )
  const code = await runScript(script, withConfig(withProfile(args, commandArgs)))
  if (code !== 0) process.exitCode = code
}

async function runSubscribe(args, commandArgs = args) {
  const script = path.join(
    runtimeRoot(),
    "skill",
    "tapcanvas-api",
    "scripts",
    "subscribe.mjs",
  )
  const code = await runScript(script, withConfig(withProfile(args, commandArgs)))
  if (code !== 0) process.exitCode = code
}

async function doctor(args) {
  const file = configPath()
  const { profile, apiBaseUrl, apiKey } = await readPlatformConfig(args, {
    requireApiKey: true,
  })

  const headers = { Authorization: `Bearer ${apiKey}`, Accept: "application/json" }
  async function fetchDoctorJson(url, label) {
    const response = await fetch(url, { headers })
    const responseText = await response.text()
    if (!response.ok) {
      throw new Error(`${label}验证失败（HTTP ${response.status}）：${responseText.slice(0, 500)}`)
    }
    try {
      return responseText ? JSON.parse(responseText) : null
    } catch {
      throw new Error(`${label}收到非 JSON 响应`)
    }
  }
  const [data, catalogModels] = await Promise.all([
    fetchDoctorJson(buildTapCanvasApiUrl({
      profile,
      apiBaseUrl,
      pathname: "/public/v1/models",
      access: "public",
    }), "TapCanvas 公共 API "),
    fetchDoctorJson(buildTapCanvasApiUrl({
      profile,
      apiBaseUrl,
      pathname: "/model-catalog/models?enabled=true",
      access: "protected",
    }), "TapCanvas 用户权限 "),
  ])
  const modelCount = Array.isArray(data?.data)
    ? data.data.length
    : Array.isArray(data?.models)
      ? data.models.length
      : null
  const catalogModelCount = Array.isArray(catalogModels) ? catalogModels.length : null
  const skillPath = path.join(
    process.env.CODEX_HOME || path.join(os.homedir(), ".codex"),
    "skills",
    "tapcanvas-api",
    "SKILL.md",
  )
  const skillStat = await fs.stat(skillPath).catch(() => null)
  if (!skillStat?.isFile()) throw new Error(`TapCanvas API Skill 不存在：${skillPath}`)
  printJson({
    ok: true,
    cliVersion: PLATFORM_CLI_VERSION,
    profile,
    apiBaseUrl,
    configPath: file,
    skillPath,
    modelCount,
    catalogModelCount,
  })
}

async function setProfileConfig(args) {
  const file = configPath()
  const profile = resolveTapCanvasProfile(
    { profile: optionValue(args, "--profile") },
  )
  const apiBaseUrl = requiredOption(args, "--api-base-url")
  if (!hasOption(args, "--api-key-stdin")) {
    throw new Error("配置 API Key 必须使用 --api-key-stdin 从标准输入读取")
  }
  if (process.stdin.isTTY) {
    throw new Error("--api-key-stdin 不接受交互终端；请通过受控管道传入，避免终端回显密钥")
  }
  const apiKey = String(await readStdinText()).trim()
  if (!apiKey.startsWith("tc_sk_") || apiKey.length <= "tc_sk_".length) {
    throw new Error("标准输入不是有效的 TapCanvas API Key")
  }
  const current = await readConfigDocument(file, { allowMissing: true })
  const next = createTapCanvasConfigWithProfile({
    current,
    file,
    profile,
    apiBaseUrl,
    apiKey,
  })
  await atomicWriteConfig(file, next)
  printJson({
    ok: true,
    profile,
    apiBaseUrl: next.profiles[profile].apiBaseUrl,
    configPath: file,
    hasApiKey: true,
  })
}

async function listProfileConfigs() {
  const file = configPath()
  const document = await readConfigDocument(file)
  printJson({
    ok: true,
    configPath: file,
    profiles: describeTapCanvasProfiles(document, file),
  })
}

function printHelp() {
  process.stdout.write(
    [
      `tapcanvas ${PLATFORM_CLI_VERSION}`,
      "",
      "Usage:",
      "  tapcanvas config set --profile <local|production> --api-base-url <url> --api-key-stdin",
      "  tapcanvas config list",
      "  tapcanvas doctor --profile <local|production> --json",
      "  tapcanvas projects list --profile <local|production>",
      "  tapcanvas flows list --profile <local|production> --project-id <id>",
      "  tapcanvas flows get --profile <local|production> --flow-id <id>",
      "  tapcanvas assets upload --profile <local|production> --file <path> --project-id <id> [--name <name>] [--content-type <mime>]",
      "  tapcanvas agent-api submit --profile <local|production> --prompt <text> --model-key <key> [--target-duration-seconds <1-180>] [--video-resolution <value>] [--aspect-ratio <value>] [--image-url <url>]... [--video-url <url>]... [--project-id <id> --flow-id <id>]",
      "  tapcanvas agent-api status --profile <local|production> --job-id <id>",
      "  tapcanvas agent-api wait --profile <local|production> --job-id <id> [--interval <seconds>] [--timeout <seconds>]",
      "  tapcanvas tools list --profile <local|production> --project-id <id> [scope options]",
      "  tapcanvas tools schema --profile <local|production> --name <tool> --project-id <id> [scope options] [--selector-field <field> --selector-value <value>]",
      "  tapcanvas tools call --profile <local|production> --name <tool> --project-id <id> [scope options] --input '<json>'",
      "  tapcanvas api call --profile <local|production> --endpoint <name> [endpoint options]",
      "  tapcanvas events subscribe --profile <local|production> (--flow-id <id> | --project-id <id> | --chapter-id <id>)",
      "",
      "Scope options:",
      "  [--flow-id <id> | --chapter-id <id>] [--book-id <id>] [--node-id <id>] [--execution-id <id>]",
      "  Canonical chapter IDs automatically provide their book scope.",
      "",
      "All API command results are JSON. Event subscriptions are NDJSON.",
      "",
    ].join("\n"),
  )
}

async function main() {
  const args = process.argv.slice(2)
  if (!args.length || args.includes("--help") || args.includes("-h")) {
    printHelp()
    return
  }
  if (args[0] === "--version" || args[0] === "version") {
    printJson({ name: "tapcanvas", version: PLATFORM_CLI_VERSION })
    return
  }
  if (args[0] === "config" && args[1] === "set") {
    await setProfileConfig(args)
    return
  }
  if (args[0] === "config" && args[1] === "list") {
    await listProfileConfigs()
    return
  }
  if (args[0] === "doctor") {
    await doctor(args)
    return
  }
  if (args[0] === "api" && args[1] === "call") {
    await runApi(args.slice(2))
    return
  }
  if (args[0] === "projects" && args[1] === "list") {
    await runApi(["--endpoint", "projects"], args)
    return
  }
  if (args[0] === "flows" && args[1] === "list") {
    await runApi([
      "--endpoint",
      "flows",
      "--projectId",
      requiredOption(args, "--project-id"),
    ], args)
    return
  }
  if (args[0] === "flows" && args[1] === "get") {
    await runApi([
      "--endpoint",
      "flowGet",
      "--flowId",
      requiredOption(args, "--flow-id"),
    ], args)
    return
  }
  if (args[0] === "assets" && args[1] === "upload") {
    await uploadAsset(args)
    return
  }
  if (args[0] === "agent-api" && args[1] === "submit") {
    await submitAgentApiVideo(args)
    return
  }
  if (args[0] === "agent-api" && args[1] === "status") {
    await showAgentApiVideoStatus(args)
    return
  }
  if (args[0] === "agent-api" && args[1] === "wait") {
    await waitForAgentApiVideo(args)
    return
  }
  if (args[0] === "tools" && args[1] === "call") {
    const scope = readToolScope(args)
    let toolArgs
    try {
      toolArgs = JSON.parse(requiredOption(args, "--input"))
    } catch {
      throw new Error("--input 必须是合法 JSON")
    }
    if (!toolArgs || typeof toolArgs !== "object" || Array.isArray(toolArgs)) {
      throw new Error("--input 必须是 JSON 对象")
    }
    const payload = {
      toolName: requiredOption(args, "--name"),
      ...scope,
      args: mergeScopedToolArgs(toolArgs, scope),
    }
    await runApi(["--endpoint", "toolExecute", "--payload", JSON.stringify(payload)], args)
    return
  }
  if (args[0] === "tools" && args[1] === "schema") {
    const scope = readToolScope(args)
    const selectorField = optionValue(args, "--selector-field").trim()
    const selectorValue = optionValue(args, "--selector-value").trim()
    if (Boolean(selectorField) !== Boolean(selectorValue)) {
      throw new Error("--selector-field 与 --selector-value 必须同时提供")
    }
    const payload = {
      toolName: "tapcanvas_tool_schema_get",
      ...scope,
      args: {
        name: requiredOption(args, "--name"),
        ...(selectorField
          ? { selector: { field: selectorField, value: selectorValue } }
          : {}),
      },
    }
    await runApi(["--endpoint", "toolExecute", "--payload", JSON.stringify(payload)], args)
    return
  }
  if (args[0] === "tools" && args[1] === "list") {
    const payload = {
      toolName: "tapcanvas_tool_catalog_get",
      ...readToolScope(args),
      args: {},
    }
    await runApi(["--endpoint", "toolExecute", "--payload", JSON.stringify(payload)], args)
    return
  }
  if (args[0] === "events" && args[1] === "subscribe") {
    const forwarded = []
    for (const [source, target] of [
      ["--flow-id", "--flowId"],
      ["--project-id", "--projectId"],
      ["--chapter-id", "--chapterId"],
      ["--wait-for", "--waitFor"],
      ["--timeout", "--timeout"],
    ]) {
      const value = optionValue(args, source).trim()
      if (value) forwarded.push(target, value)
    }
    await runSubscribe(forwarded, args)
    return
  }
  throw new Error(`无法识别 TapCanvas CLI 命令：${args.join(" ")}`)
}

main().catch((error) => {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`)
  process.exitCode = 1
})
