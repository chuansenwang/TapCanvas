import { promises as fs } from "node:fs"
import path from "node:path"
import {
  isPlainObject,
  requireArgv,
  requireFiniteInRange,
  requireIntegerInRange,
  requireNonEmptyString,
  runProcess,
  sha256,
} from "./process-utils.mjs"

export const WORKSPACE_CONFIG_RELATIVE_PATH = path.join(
  ".tapcanvas",
  "codex-workspace.json",
)

const WORKSPACE_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$/u
const ENVIRONMENT_NAME_PATTERN = /^[A-Za-z_][A-Za-z0-9_]*$/u
const SUPPORTED_REMOTE_RUNTIMES = new Set(["node22", "node24", "node26"])
const MAX_ARCHIVE_BYTES = 250 * 1024 * 1024

function requireRelativePath(value, field) {
  const parsed = requireNonEmptyString(value, field, 500)
  if (path.isAbsolute(parsed)) {
    throw new Error(`${field} 必须是 workspace 内的相对路径`)
  }
  const normalized = path.posix.normalize(parsed.replaceAll("\\", "/"))
  if (normalized === ".." || normalized.startsWith("../")) {
    throw new Error(`${field} 不允许逃逸 workspace`)
  }
  return normalized.replace(/^\.\//u, "")
}

function parseRemoteBuild(value) {
  if (!isPlainObject(value) || value.provider !== "vercel-sandbox") {
    throw new Error("remoteBuild.provider 必须明确配置为 vercel-sandbox")
  }
  const runtime = requireNonEmptyString(value.runtime, "remoteBuild.runtime", 40)
  if (!SUPPORTED_REMOTE_RUNTIMES.has(runtime)) {
    throw new Error("remoteBuild.runtime 仅支持 node22、node24 或 node26")
  }
  return {
    provider: "vercel-sandbox",
    runtime,
    timeoutMs: requireIntegerInRange(
      value.timeoutMs,
      "remoteBuild.timeoutMs",
      60_000,
      86_400_000,
    ),
    vcpus: requireIntegerInRange(value.vcpus, "remoteBuild.vcpus", 1, 8),
  }
}

function parseLocalDocker(value) {
  if (value === null || typeof value === "undefined") return null
  if (!isPlainObject(value)) {
    throw new Error("localDocker 必须是对象；不需要本地兜底时请省略")
  }
  const image = requireNonEmptyString(value.image, "localDocker.image", 300)
  if (!/@sha256:[a-f0-9]{64}$/u.test(image)) {
    throw new Error(
      "localDocker.image 必须使用不可变的 @sha256 digest，禁止可漂移 tag",
    )
  }
  return {
    image,
    timeoutMs: requireIntegerInRange(
      value.timeoutMs,
      "localDocker.timeoutMs",
      60_000,
      86_400_000,
    ),
    memoryMb: requireIntegerInRange(
      value.memoryMb,
      "localDocker.memoryMb",
      256,
      65_536,
    ),
    cpus: requireFiniteInRange(value.cpus, "localDocker.cpus", 0.25, 16),
    pidsLimit: requireIntegerInRange(
      value.pidsLimit,
      "localDocker.pidsLimit",
      32,
      4_096,
    ),
  }
}

function parseEnvironmentVariables(value) {
  if (typeof value === "undefined") return []
  if (!Array.isArray(value) || value.length > 64) {
    throw new Error("environmentVariables 必须是最多 64 项的环境变量名数组")
  }
  const names = value.map((item, index) => {
    const name = requireNonEmptyString(item, `environmentVariables[${index}]`, 120)
    if (!ENVIRONMENT_NAME_PATTERN.test(name)) {
      throw new Error(`environmentVariables[${index}] 不是合法环境变量名`)
    }
    return name
  })
  if (new Set(names).size !== names.length) {
    throw new Error("environmentVariables 不允许重复")
  }
  return names
}

function parseWorkspaceConfig(value) {
  if (!isPlainObject(value) || value.version !== 1) {
    throw new Error("workspace 配置 version 必须为 1")
  }
  const id = requireNonEmptyString(value.id, "id", 80)
  if (!WORKSPACE_ID_PATTERN.test(id)) {
    throw new Error("id 只能使用字母、数字、点、下划线和连字符，最长 80 字符")
  }
  if (!isPlainObject(value.commands)) {
    throw new Error("commands 必须明确包含 install、test、build、preview")
  }
  const previewReadyPath = requireNonEmptyString(
    value.previewReadyPath,
    "previewReadyPath",
    500,
  )
  if (!previewReadyPath.startsWith("/") || previewReadyPath.includes("://")) {
    throw new Error("previewReadyPath 必须是以 / 开头的站内路径")
  }
  return {
    version: 1,
    id,
    label: requireNonEmptyString(value.label, "label", 120),
    commands: {
      install: requireArgv(value.commands.install, "commands.install"),
      test: requireArgv(value.commands.test, "commands.test"),
      build: requireArgv(value.commands.build, "commands.build"),
      preview: requireArgv(value.commands.preview, "commands.preview"),
    },
    outputDirectory: requireRelativePath(value.outputDirectory, "outputDirectory"),
    previewPort: requireIntegerInRange(value.previewPort, "previewPort", 1_024, 65_535),
    previewReadyPath,
    previewReadyTimeoutMs: requireIntegerInRange(
      value.previewReadyTimeoutMs,
      "previewReadyTimeoutMs",
      5_000,
      300_000,
    ),
    remoteBuild: parseRemoteBuild(value.remoteBuild),
    localDocker: parseLocalDocker(value.localDocker),
    environmentVariables: parseEnvironmentVariables(value.environmentVariables),
  }
}

function readEnvironment(config, environment) {
  const resolved = {}
  for (const name of config.environmentVariables) {
    const value = environment[name]
    if (typeof value !== "string") {
      throw new Error(`workspace ${config.id} 缺少显式要求的环境变量 ${name}`)
    }
    resolved[name] = value
  }
  return resolved
}

export async function isDockerAvailable(options = {}) {
  const result = await runProcess(
    options.dockerBinary || process.env.DOCKER_BINARY || "docker",
    ["info", "--format", "{{.ServerVersion}}"],
    {
      timeoutMs: 10_000,
      env: options.environment || process.env,
    },
  ).catch(() => null)
  return Boolean(result && result.exitCode === 0 && result.stdout.trim())
}

export async function loadWorkspace(workspacePath, options = {}) {
  const workspaceRoot = await fs.realpath(path.resolve(workspacePath))
  const stat = await fs.stat(workspaceRoot)
  if (!stat.isDirectory()) {
    throw new Error(`workspace 不是目录：${workspaceRoot}`)
  }
  const configPath = path.join(workspaceRoot, WORKSPACE_CONFIG_RELATIVE_PATH)
  let raw
  try {
    raw = await fs.readFile(configPath, "utf8")
  } catch (error) {
    if (error && typeof error === "object" && error.code === "ENOENT") {
      throw new Error(
        `workspace 缺少 ${WORKSPACE_CONFIG_RELATIVE_PATH}：${workspaceRoot}`,
      )
    }
    throw error
  }
  let json
  try {
    json = JSON.parse(raw)
  } catch {
    throw new Error(`workspace 配置不是合法 JSON：${configPath}`)
  }
  const config = parseWorkspaceConfig(json)
  const environment = readEnvironment(config, options.environment || process.env)
  const configFingerprint = sha256(JSON.stringify(config))
  const dockerAvailable =
    typeof options.dockerAvailable === "boolean"
      ? options.dockerAvailable
      : config.localDocker
        ? await isDockerAvailable({
            dockerBinary: options.dockerBinary,
            environment: options.environment,
          })
        : false
  return {
    root: workspaceRoot,
    configPath,
    config,
    environment,
    configFingerprint,
    archiveMaxBytes: MAX_ARCHIVE_BYTES,
    summary: {
      id: config.id,
      label: config.label,
      configFingerprint,
      remoteBuildConfigured: config.remoteBuild.provider === "vercel-sandbox",
      localDockerConfigured: Boolean(config.localDocker && dockerAvailable),
    },
  }
}

export async function loadWorkspaces(workspacePaths, options = {}) {
  if (!Array.isArray(workspacePaths) || workspacePaths.length === 0) {
    throw new Error("至少需要一个 --workspace 目录")
  }
  const dockerAvailable =
    typeof options.dockerAvailable === "boolean"
      ? options.dockerAvailable
      : await isDockerAvailable({
          dockerBinary: options.dockerBinary,
          environment: options.environment,
        })
  const workspaces = []
  for (const workspacePath of workspacePaths) {
    workspaces.push(
      await loadWorkspace(workspacePath, {
        ...options,
        dockerAvailable,
      }),
    )
  }
  const ids = workspaces.map((workspace) => workspace.config.id)
  if (new Set(ids).size !== ids.length) {
    throw new Error("已授权 workspace 的 id 必须全局唯一")
  }
  return workspaces
}

export function workspaceById(workspaces, workspaceId) {
  const workspace = workspaces.find((item) => item.config.id === workspaceId)
  if (!workspace) {
    throw new Error(`任务引用了未授权 workspaceId：${workspaceId}`)
  }
  return workspace
}
