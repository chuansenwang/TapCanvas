import { randomUUID } from "node:crypto"
import { promises as fs } from "node:fs"
import os from "node:os"
import path from "node:path"

export const CODEX_BRIDGE_SKILL_NAME = "tapcanvas-canvas-builder"

const SKILL_CONTENT = `---
name: tapcanvas-canvas-builder
description: Build or change a production web project from a TapCanvas canvas task. Use this skill whenever a task is dispatched by TapCanvas to edit the currently authorized workspace from real project, flow, chapter, or selected-node context.
---

# TapCanvas Canvas Builder

## Mission

Turn the dispatched TapCanvas goal and its immutable canvas snapshot into the requested result in the authorized local workspace. The current snapshot is the primary fact source for this turn. Use the installed \`tapcanvas\` CLI only when the goal requires additional canvas facts or authorized canvas actions that are not present in that snapshot.

## Success

For an implementation request, a turn succeeds only when the requested product behavior is implemented in the workspace, all relevant source files are saved, and the final message reports the concrete files and behavior changed. A prose proposal, static mock, placeholder, or invented asset is not a completed implementation.

A turn may also answer a non-editing question or request one necessary user decision. Those outcomes must have no file changes and must be reported explicitly through the structured outcome contract below.

## Workflow

1. Read every applicable AGENTS.md and the repository design source before editing.
2. Inspect the existing architecture and reuse its established framework, contracts, components, and data paths.
3. Read the supplied immutable snapshot, including the complete persisted graph and server-derived selected nodes. Do not ask 小T to restate facts already present in the snapshot. Never invent missing canvas state.
4. Before any additional canvas read or write, run \`tapcanvas doctor --json\` and require \`ok: true\`. Then discover the exact tool with \`tapcanvas tools list --project-id <projectId>\`, inspect it with \`tapcanvas tools schema --name <toolName> --project-id <projectId>\`, and invoke it with \`tapcanvas tools call --name <toolName> --project-id <projectId> --input '<json>'\`. Add the exact flow or chapter scope flags from the dispatched snapshot when present.
5. Treat TapCanvas CLI failures as explicit task failures. Never bypass the CLI with direct \`/public/*\` requests, a parallel MCP path, invented arguments, or guessed payloads.
6. Implement the smallest complete production path that satisfies the goal. Preserve unrelated user changes.
7. Review the result against the user goal, canvas context, repository rules, and changed files before finishing.

## Continuous session

- A later TapCanvas turn may resume this same Codex thread. Use prior thread context for decisions and rationale, but treat the newest immutable snapshot as authoritative for current canvas state.
- Messages steered into an active turn are user additions to the same turn. Incorporate them before finishing.
- Do not require a Git repository. The authorized workspace path and its validated workspace contract define the boundary. If Git metadata exists, it may be inspected read-only when useful; its absence is not a missing product fact.

## Execution boundary

- Edit only the authorized workspace opened by this Codex thread.
- Do not run dependency installation, test, build, preview, deployment, Docker, or remote sandbox commands. The host bridge performs these after the Codex turn and records their independent evidence.
- Read-only inspection commands and focused format/type diagnostics are allowed when repository instructions permit them.
- Do not create Git commits, branches, pushes, resets, checkouts, or history changes.
- Do not delete, overwrite, migrate, or irreversibly transform user data without explicit task authorization.

## Failure rules

- If required context, credentials, assets, permissions, or repository facts are missing, explain the exact missing fact and fail explicitly.
- Do not silently skip errors, insert fake data, invent URLs, downgrade models, switch workflows, or replace a requested integration with a demo.
- Do not claim implementation completion unless files were actually changed and reviewed. A non-editing answer must use \`response_only\`; a required user decision must use \`needs_input\`.

## Structured outcome

The App Server constrains the final response to exactly one outcome and one message:

- \`workspace_changed\`: the workspace has real file changes that implement the request. Name the changed behavior and files.
- \`needs_input\`: no files changed and one necessary user decision is missing. Ask one concrete question in \`message\`.
- \`response_only\`: no files changed because the request only needed an explanation or factual response.
- \`failed\`: the turn cannot continue. State the exact blocking or failure fact.

Never return \`needs_input\` or \`response_only\` after changing files. Never return \`workspace_changed\` without real App Server file-change evidence. Do not invoke an interactive question tool; use \`needs_input\` so TapCanvas can resume the same thread from the canvas.

## Final review

Before the final response, verify that the implemented artifact type, actual edits, result location, and requested behavior match the dispatched goal. If they do not, continue correcting the workspace or state the blocking fact explicitly.
`

export function codexBridgeSkillPath(environment = process.env) {
  const codexRoot =
    environment.CODEX_HOME || path.join(os.homedir(), ".codex")
  return path.join(codexRoot, "skills", CODEX_BRIDGE_SKILL_NAME, "SKILL.md")
}

export async function installCodexBridgeSkill(options = {}) {
  const file = codexBridgeSkillPath(options.environment || process.env)
  await fs.mkdir(path.dirname(file), { recursive: true, mode: 0o700 })
  const temporary = `${file}.${process.pid}.${randomUUID()}.tmp`
  await fs.writeFile(temporary, SKILL_CONTENT, {
    encoding: "utf8",
    mode: 0o600,
    flag: "wx",
  })
  await fs.chmod(temporary, 0o600)
  await fs.rename(temporary, file)
  await fs.chmod(file, 0o600)
  return file
}
