import { createHash, randomUUID } from "node:crypto"
import { createReadStream, promises as fs } from "node:fs"
import os from "node:os"
import path from "node:path"
import { commandDisplay, runProcess } from "./process-utils.mjs"

const EXCLUDED_PATHS = [
  ".git",
  ".hg",
  ".svn",
  "node_modules",
  "dist",
  "build",
  ".next",
  ".nuxt",
  ".output",
  "coverage",
  ".cache",
  ".turbo",
  ".vercel",
  ".env",
  ".env.*",
  ".npmrc",
  ".pnpmrc",
  ".yarnrc",
  ".yarnrc.yml",
  ".ssh",
  "*.pem",
  "*.key",
  "*.p12",
  "*.pfx",
]

async function fileSha256(file) {
  const hash = createHash("sha256")
  const stream = createReadStream(file)
  for await (const chunk of stream) hash.update(chunk)
  return hash.digest("hex")
}

export async function createSourceArchive(workspace) {
  const temporaryDirectory = await fs.mkdtemp(
    path.join(os.tmpdir(), "tapcanvas-codex-source-"),
  )
  const archivePath = path.join(
    temporaryDirectory,
    `source-${randomUUID()}.tgz`,
  )
  const args = [
    "-czf",
    archivePath,
    "--no-xattrs",
    ...EXCLUDED_PATHS.flatMap((item) => ["--exclude", item]),
    "-C",
    workspace.root,
    ".",
  ]
  const result = await runProcess(
    process.env.TAR_BINARY || "tar",
    args,
    {
      timeoutMs: 5 * 60 * 1_000,
      logLimitBytes: 64 * 1024,
    },
  )
  if (result.exitCode !== 0) {
    await fs.rm(temporaryDirectory, { recursive: true, force: true })
    throw new Error(
      `源码归档失败（${commandDisplay(["tar", ...args])}）：${
        result.stderr || result.stdout
      }`,
    )
  }
  const stat = await fs.stat(archivePath)
  if (stat.size <= 0) {
    await fs.rm(temporaryDirectory, { recursive: true, force: true })
    throw new Error("源码归档为空")
  }
  if (stat.size > workspace.archiveMaxBytes) {
    await fs.rm(temporaryDirectory, { recursive: true, force: true })
    throw new Error(
      `源码归档 ${stat.size} bytes 超过限制 ${workspace.archiveMaxBytes} bytes`,
    )
  }
  return {
    archivePath,
    archiveBytes: stat.size,
    sha256: await fileSha256(archivePath),
    async cleanup() {
      await fs.rm(temporaryDirectory, { recursive: true, force: true })
    },
  }
}
