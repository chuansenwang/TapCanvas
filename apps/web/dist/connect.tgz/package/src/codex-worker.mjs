import { randomUUID } from "node:crypto"
import { promises as fs } from "node:fs"
import path from "node:path"
import { readBridgeConfig, bridgeConfigPath } from "./bridge-config.mjs"
import {
  BridgeHttpClient,
  BridgeHttpError,
  uploadSourceArchive,
} from "./bridge-http-client.mjs"
import {
  readCodexVersion,
  runCodexTaskWithAppServer,
} from "./codex-app-server.mjs"
import { classifyCodexTurnResult } from "./codex-turn-result.mjs"
import {
  codexBridgeSkillPath,
  installCodexBridgeSkill,
} from "./codex-skill.mjs"
import {
  cleanupExpiredLocalPreviews,
  LocalDockerBuildFailure,
  runLocalDockerBuild,
} from "./local-docker.mjs"
import { errorMessage, sleep } from "./process-utils.mjs"
import { createSourceArchive } from "./source-archive.mjs"
import {
  isDockerAvailable,
  loadWorkspaces,
  workspaceById,
} from "./workspace-config.mjs"
import { CONNECT_VERSION } from "./version.mjs"

const PROTOCOL_VERSION = 2
const HEARTBEAT_INTERVAL_MS = 15_000
const LEASE_HEARTBEAT_INTERVAL_MS = 8_000
const CLAIM_INTERVAL_MS = 2_000
const RESULT_POLL_INTERVAL_MS = 2_000
const DEFAULT_FALLBACK_APPROVAL_TIMEOUT_MS = 30 * 60 * 1_000
const DEFAULT_REMOTE_QUEUE_GRACE_MS = 15 * 60 * 1_000
const TERMINAL_STATES = new Set([
  "awaiting_user_input",
  "codex_failed",
  "remote_build_failed_code",
  "succeeded",
  "failed",
  "canceled",
  "unknown",
])

class RemoteBuildSubmissionUnknownError extends Error {
  constructor(message) {
    super(message)
    this.name = "RemoteBuildSubmissionUnknownError"
  }
}

function log(level, message, details = null) {
  const suffix = details ? ` ${JSON.stringify(details)}` : ""
  const line = `[tapcanvas-codex-bridge] ${new Date().toISOString()} ${level} ${message}${suffix}\n`
  if (level === "ERROR") process.stderr.write(line)
  else process.stdout.write(line)
}

function readBoundedDuration(environment, name, defaultValue, minimum, maximum) {
  const raw = environment[name]
  if (typeof raw === "undefined" || String(raw).trim() === "") {
    return defaultValue
  }
  const parsed = Number(raw)
  if (!Number.isInteger(parsed) || parsed < minimum || parsed > maximum) {
    throw new Error(`${name} 必须是 ${minimum} 到 ${maximum} 之间的整数`)
  }
  return parsed
}

function isTerminalTask(task) {
  return Boolean(task && TERMINAL_STATES.has(task.state))
}

function requireClaim(value) {
  if (
    !value ||
    typeof value !== "object" ||
    !value.task ||
    !value.contextSnapshot ||
    typeof value.leaseId !== "string" ||
    !value.leaseId
  ) {
    throw new Error("TapCanvas claim 响应缺少 task、contextSnapshot 或 leaseId")
  }
  return value
}

function createEmptyEvidence() {
  return {
    source: null,
    codex: null,
    build: null,
    preview: null,
  }
}

function remoteBuildSpec(workspace) {
  return {
    configFingerprint: workspace.configFingerprint,
    runtime: workspace.config.remoteBuild.runtime,
    timeoutMs: workspace.config.remoteBuild.timeoutMs,
    vcpus: workspace.config.remoteBuild.vcpus,
    commands: workspace.config.commands,
    outputDirectory: workspace.config.outputDirectory,
    previewPort: workspace.config.previewPort,
    previewReadyPath: workspace.config.previewReadyPath,
    previewReadyTimeoutMs: workspace.config.previewReadyTimeoutMs,
    environment: workspace.environment,
  }
}

function leasePayload(context) {
  return {
    bridgeId: context.bridgeId,
    workerInstanceId: context.workerInstanceId,
    leaseId: context.leaseId,
  }
}

function workerUpdatePayload(context, input) {
  return {
    ...leasePayload(context),
    state: input.state,
    code: input.code,
    message: input.message,
		...(input.deliveryEvidence
			? { deliveryEvidence: input.deliveryEvidence }
			: {}),
		...(input.expectedDelivery
			? { expectedDelivery: input.expectedDelivery }
			: {}),
	}
}

export function isUncertainBridgeWrite(error) {
  return (
    error instanceof BridgeHttpError &&
    (error.status === 0 ||
      error.status >= 500 ||
      error.code === "invalid_json_response")
  )
}

export async function enqueueRemoteBuildWithConfirmation(input) {
  let lastError = null
  for (let attempt = 1; attempt <= 2; attempt += 1) {
    try {
      await input.client.enqueueRemoteBuild(
        input.taskId,
        input.payload,
        input.signal,
      )
      return null
    } catch (error) {
      const stateMayHaveAdvanced =
        error instanceof BridgeHttpError &&
        error.code === "codex_remote_build_state_conflict"
      if (!isUncertainBridgeWrite(error) && !stateMayHaveAdvanced) throw error
      lastError = error
      try {
        const observed = await input.client.getTask(
          input.taskId,
          input.signal,
        )
        if (observed.state !== "remote_build_queued") return observed
        if (stateMayHaveAdvanced) throw error
      } catch (readError) {
        lastError = new Error(
          `${errorMessage(error)}；任务状态确认也失败：${errorMessage(readError)}`,
        )
      }
      if (attempt < 2) {
        log("ERROR", "远程构建提交响应不确定，使用同一 taskId 幂等确认一次", {
          taskId: input.taskId,
          error: errorMessage(lastError),
        })
      }
    }
  }
  throw new RemoteBuildSubmissionUnknownError(
    `远程构建提交结果无法确认；没有自动创建第二个任务：${errorMessage(lastError)}`,
  )
}

async function acquireProcessLock(environment) {
  const configFile = bridgeConfigPath(environment)
  const file = `${configFile}.worker.lock`
  await fs.mkdir(path.dirname(file), { recursive: true, mode: 0o700 })
  const write = async () => {
    const handle = await fs.open(file, "wx", 0o600)
    await handle.writeFile(
      `${JSON.stringify({
        pid: process.pid,
        startedAt: new Date().toISOString(),
      })}\n`,
      "utf8",
    )
    await handle.close()
  }
  try {
    await write()
  } catch (error) {
    if (!error || typeof error !== "object" || error.code !== "EEXIST") {
      throw error
    }
    let pid = 0
    try {
      const parsed = JSON.parse(await fs.readFile(file, "utf8"))
      pid = Number(parsed?.pid)
    } catch {
      pid = 0
    }
    let alive = false
    if (Number.isInteger(pid) && pid > 0) {
      try {
        process.kill(pid, 0)
        alive = true
      } catch {
        alive = false
      }
    }
    if (alive) {
      throw new Error(`Codex Bridge 已在运行（pid=${pid}）`)
    }
    await fs.unlink(file)
    await write()
  }
  return async () => {
    try {
      const parsed = JSON.parse(await fs.readFile(file, "utf8"))
      if (Number(parsed?.pid) === process.pid) await fs.unlink(file)
    } catch {
      // The exact process lock is already gone; there is nothing to release.
    }
  }
}

function startLeaseKeeper(input) {
  let stopped = false
  let loopPromise = null
  const stopController = new AbortController()
  const loop = async () => {
    while (!stopped && !input.executionSignal.aborted) {
      try {
        await sleep(LEASE_HEARTBEAT_INTERVAL_MS, stopController.signal)
      } catch {
        return
      }
      if (stopped || input.executionSignal.aborted) return
      try {
        await input.client.heartbeatLease(
          input.taskId,
          leasePayload(input),
          input.executionSignal,
        )
      } catch (error) {
        try {
          const task = await input.client.getTask(input.taskId)
          if (isTerminalTask(task)) return
        } catch {
          // The original lease failure remains the trustworthy failure.
        }
        input.abortExecution(
          new Error(`Codex 任务租约丢失：${errorMessage(error)}`),
        )
        return
      }
    }
  }
  loopPromise = loop()
  return {
    async stop() {
      stopped = true
      stopController.abort()
      await loopPromise
    },
  }
}

async function waitForTaskState(input) {
  while (Date.now() < input.deadlineMs) {
    if (input.signal.aborted) {
      throw input.signal.reason instanceof Error
        ? input.signal.reason
        : new Error("Codex 任务轮询已取消")
    }
    const task = await input.client.getTask(input.taskId, input.signal)
    if (input.accept(task)) return task
    await sleep(RESULT_POLL_INTERVAL_MS, input.signal)
  }
  throw new Error(input.timeoutMessage)
}

async function finishAsFailure(context, input) {
  try {
    return await context.client.updateTask(
      context.taskId,
      workerUpdatePayload(context, {
        state: input.state || "failed",
        code: input.code,
        message: input.message,
        deliveryEvidence: input.deliveryEvidence,
      }),
    )
  } catch (error) {
    log("ERROR", "无法写回任务失败状态", {
      taskId: context.taskId,
      originalFailure: input.message,
      updateFailure: errorMessage(error),
    })
    throw error
  }
}

async function handleLocalFallback(context, input) {
  let task = input.task
  if (task.fallbackPolicy !== "ask") {
    await finishAsFailure(context, {
      code: "remote_infrastructure_failed_fallback_disabled",
      message:
        "远程 Sandbox 基础设施失败，且本任务未允许请求本机 Docker fallback。",
      deliveryEvidence: task.deliveryEvidence,
    })
    return
  }
  if (!input.workspace.config.localDocker || !input.workspace.summary.localDockerConfigured) {
    await finishAsFailure(context, {
      code: "local_fallback_unavailable",
      message:
        "远程 Sandbox 基础设施失败，但已授权 workspace 没有可用的本机隔离 Docker 配置。",
      deliveryEvidence: task.deliveryEvidence,
    })
    return
  }
  task = await context.client.updateTask(
    context.taskId,
    workerUpdatePayload(context, {
      state: "fallback_waiting_approval",
      code: "local_fallback_approval_required",
      message:
        "远程 Sandbox 发生基础设施故障。只有你在画布明确批准后，才会在本机隔离 Docker 中执行安装、测试、构建与预览。",
      deliveryEvidence: task.deliveryEvidence,
    }),
    input.signal,
  )
  const approvalTimeoutMs = readBoundedDuration(
    input.environment,
    "CODEX_FALLBACK_APPROVAL_TIMEOUT_MS",
    DEFAULT_FALLBACK_APPROVAL_TIMEOUT_MS,
    60_000,
    24 * 60 * 60 * 1_000,
  )
  try {
    task = await waitForTaskState({
      client: context.client,
      taskId: context.taskId,
      signal: input.signal,
      deadlineMs: Date.now() + approvalTimeoutMs,
      accept: (candidate) =>
        candidate.state !== "fallback_waiting_approval",
      timeoutMessage: `等待本机 Docker fallback 审批超过 ${approvalTimeoutMs}ms`,
    })
  } catch (error) {
    await finishAsFailure(context, {
      code: "local_fallback_approval_timeout",
      message: errorMessage(error),
      deliveryEvidence: task.deliveryEvidence,
    })
    return
  }
  if (task.state !== "local_fallback_approved") {
    if (isTerminalTask(task)) return
    await finishAsFailure(context, {
      code: "local_fallback_unexpected_state",
      message: `本机 fallback 审批后出现非预期状态：${task.state}`,
      deliveryEvidence: task.deliveryEvidence,
    })
    return
  }
  task = await context.client.updateTask(
    context.taskId,
    workerUpdatePayload(context, {
      state: "local_build_running",
      code: "local_docker_build_started",
      message:
        "已收到画布中的明确批准，正在本机隔离 Docker 内执行安装、测试、构建与预览。",
      deliveryEvidence: task.deliveryEvidence,
    }),
    input.signal,
  )
  try {
    const result = await runLocalDockerBuild({
      workspace: input.workspace,
      task,
      archive: input.archive,
      signal: input.signal,
    })
    await context.client.updateTask(
      context.taskId,
      workerUpdatePayload(context, {
        state: "succeeded",
        code: "local_docker_build_succeeded",
        message:
          "Codex 修改已通过经批准的本机隔离 Docker 测试、构建与预览验收。",
        deliveryEvidence: {
          ...task.deliveryEvidence,
          build: {
            executor: "local-docker",
            executionId: result.executionId,
            commands: result.commands,
          },
          preview: result.preview,
        },
      }),
      input.signal,
    )
  } catch (error) {
    const commands =
      error instanceof LocalDockerBuildFailure ? error.commands : []
    await finishAsFailure(context, {
      code: "local_docker_build_failed",
      message: `本机隔离 Docker 构建失败：${errorMessage(error)}`,
      deliveryEvidence: {
        ...task.deliveryEvidence,
        build:
          commands.length > 0
            ? {
                executor: "local-docker",
                executionId: error.executionId || `local-${task.id}`,
                commands,
              }
            : task.deliveryEvidence.build,
      },
    })
  }
}

async function executeClaimedTask(context, claim, workspace, input) {
  let task = claim.task
  let archive = null
  const baseEvidence = task.deliveryEvidence || createEmptyEvidence()
  try {
    if (task.workspaceConfigFingerprint !== workspace.configFingerprint) {
      await finishAsFailure(context, {
        code: "workspace_config_changed",
        message:
          "workspace 配置在任务派发后发生变化；为避免用不同命令或目录执行，任务已停止，请重新派发。",
        deliveryEvidence: baseEvidence,
      })
      return
    }
    task = await context.client.updateTask(
      context.taskId,
      workerUpdatePayload(context, {
        state: "codex_running",
        code: "codex_app_server_started",
        message:
          "宿主机正在通过 Codex App Server 编辑已授权 workspace；本回合不会执行构建命令。",
        deliveryEvidence: baseEvidence,
      }),
      input.signal,
    )

    let codexResult
    try {
      codexResult = await runCodexTaskWithAppServer(
        {
          task,
          contextSnapshot: claim.contextSnapshot,
          workspace,
          skillPath: input.skillPath,
        },
        {
          codexBinary: input.config.codexBinary,
          workerVersion: CONNECT_VERSION,
          environment: input.environment,
          signal: input.signal,
          steering: {
            claim: async () => {
              const result = await context.client.claimTaskMessages(
                context.taskId,
                {
                  ...leasePayload(context),
                  limit: 10,
                },
                input.signal,
              )
              if (!result || !Array.isArray(result.items)) {
                throw new Error("TapCanvas steering claim 响应缺少 items")
              }
              return result.items
            },
            acknowledge: (message, state, detail) =>
              context.client.acknowledgeTaskMessage(
                context.taskId,
                {
                  ...leasePayload(context),
                  messageId: message.id,
                  state,
                  detail,
                },
                input.signal,
              ),
          },
        },
      )
    } catch (error) {
      await finishAsFailure(context, {
        state: "codex_failed",
        code: "codex_app_server_failed",
        message: errorMessage(error),
        deliveryEvidence: baseEvidence,
      })
      return
    }
    const evidence = {
      ...baseEvidence,
      codex: codexResult,
    }
    const disposition = classifyCodexTurnResult(codexResult)
    if (disposition.kind === "failure") {
      await finishAsFailure(context, {
        state: "codex_failed",
        code: disposition.code,
        message: disposition.message,
        deliveryEvidence: evidence,
      })
      return
    }
    if (disposition.kind === "response") {
      await context.client.updateTask(
        context.taskId,
        workerUpdatePayload(context, {
          state: disposition.state,
          code: disposition.code,
          message: disposition.message,
          expectedDelivery: {
            kind: "codex_response",
            workspaceId: task.workspaceId,
            requiredEvidence: ["codex_turn"],
          },
          deliveryEvidence: evidence,
        }),
        input.signal,
      )
      return
    }
    task = await context.client.updateTask(
      context.taskId,
      workerUpdatePayload(context, {
        state: "remote_build_queued",
        code: "codex_workspace_changed",
        message:
          "Codex 已写入 workspace，正在生成受限源码归档并直传平台私有存储。",
        deliveryEvidence: evidence,
      }),
      input.signal,
    )

    let uploadedObjectKey = null
    try {
      archive = await createSourceArchive(workspace)
      task = await context.client.updateTask(
        context.taskId,
        workerUpdatePayload(context, {
          state: "remote_build_queued",
          code: "source_archive_created",
          message:
            "受限源码归档已创建；依赖目录、构建产物、Git 历史与常见密钥文件均未上传。",
          deliveryEvidence: {
            ...evidence,
            source: {
              sha256: archive.sha256,
              archiveBytes: archive.archiveBytes,
            },
          },
        }),
        input.signal,
      )
      const upload = await context.client.requestSourceUpload(
        context.taskId,
        {
          ...leasePayload(context),
          sourceSha256: archive.sha256,
          archiveBytes: archive.archiveBytes,
        },
        input.signal,
      )
      await uploadSourceArchive({
        uploadUrl: upload.uploadUrl,
        requiredHeaders: upload.requiredHeaders,
        archivePath: archive.archivePath,
        archiveBytes: archive.archiveBytes,
        signal: input.signal,
      })
      uploadedObjectKey = upload.objectKey
      const observedTask = await enqueueRemoteBuildWithConfirmation({
        client: context.client,
        taskId: context.taskId,
        payload: {
          ...leasePayload(context),
          sourceSha256: archive.sha256,
          archiveBytes: archive.archiveBytes,
          objectKey: upload.objectKey,
          spec: remoteBuildSpec(workspace),
        },
        signal: input.signal,
      })
      if (observedTask) task = observedTask
      uploadedObjectKey = null
    } catch (error) {
      if (error instanceof RemoteBuildSubmissionUnknownError) {
        uploadedObjectKey = null
        await finishAsFailure(context, {
          state: "unknown",
          code: "remote_build_submission_unknown",
          message: error.message,
          deliveryEvidence: task.deliveryEvidence,
        })
        return
      }
      let cleanupFailure = ""
      if (uploadedObjectKey) {
        try {
          await context.client.discardSource(
            context.taskId,
            {
              ...leasePayload(context),
              sourceSha256: archive.sha256,
              objectKey: uploadedObjectKey,
            },
            input.signal,
          )
        } catch (discardError) {
          cleanupFailure = `；私有源码清理也失败：${errorMessage(discardError)}`
        }
      }
      await finishAsFailure(context, {
        code: "remote_build_submission_failed",
        message: `远程 Sandbox 构建提交失败：${errorMessage(error)}${cleanupFailure}`,
        deliveryEvidence: task.deliveryEvidence,
      })
      return
    }

    const graceMs = readBoundedDuration(
      input.environment,
      "CODEX_REMOTE_QUEUE_GRACE_MS",
      DEFAULT_REMOTE_QUEUE_GRACE_MS,
      60_000,
      24 * 60 * 60 * 1_000,
    )
    try {
      task = await waitForTaskState({
        client: context.client,
        taskId: context.taskId,
        signal: input.signal,
        deadlineMs:
          Date.now() + workspace.config.remoteBuild.timeoutMs + graceMs,
        accept: (candidate) =>
          candidate.state !== "remote_build_queued" &&
          candidate.state !== "remote_build_running",
        timeoutMessage:
          "远程 Sandbox 在约定时限内没有返回可确认终态；禁止自动重试或本机 fallback。",
      })
    } catch (error) {
      await finishAsFailure(context, {
        state: "unknown",
        code: "remote_build_status_unknown",
        message: errorMessage(error),
        deliveryEvidence: task.deliveryEvidence,
      })
      return
    }
    if (task.state === "remote_build_failed_infrastructure") {
      await handleLocalFallback(context, {
        task,
        workspace,
        archive,
        environment: input.environment,
        signal: input.signal,
      })
      return
    }
    if (isTerminalTask(task)) return
    await finishAsFailure(context, {
      code: "remote_build_unexpected_state",
      message: `远程 Sandbox 返回了非预期状态：${task.state}`,
      deliveryEvidence: task.deliveryEvidence,
    })
  } finally {
    await archive?.cleanup()
  }
}

async function handleClaim(client, config, claim, input) {
  const task = claim.task
  const executionController = new AbortController()
  const parentAbortHandler = () =>
    executionController.abort(
      input.signal.reason instanceof Error
        ? input.signal.reason
        : new Error("Codex Bridge 正在停止"),
    )
  if (input.signal.aborted) parentAbortHandler()
  else input.signal.addEventListener("abort", parentAbortHandler, { once: true })
  const context = {
    client,
    bridgeId: config.bridgeId,
    workerInstanceId: input.workerInstanceId,
    leaseId: claim.leaseId,
    taskId: task.id,
    abortExecution: (reason) => executionController.abort(reason),
    executionSignal: executionController.signal,
  }
  const leaseKeeper = startLeaseKeeper(context)
  try {
    const workspace = workspaceById(input.workspaces, task.workspaceId)
    await executeClaimedTask(context, claim, workspace, {
      config,
      environment: input.environment,
      skillPath: input.skillPath,
      signal: executionController.signal,
    })
  } catch (error) {
    if (executionController.signal.aborted) {
      log("ERROR", "任务执行因租约或服务停止而中断；不会自动重试", {
        taskId: task.id,
        error: errorMessage(error),
      })
      return
    }
    log("ERROR", "任务执行出现未处理失败", {
      taskId: task.id,
      error: errorMessage(error),
    })
    try {
      const latest = await client.getTask(task.id)
      if (!isTerminalTask(latest)) {
        await finishAsFailure(context, {
          code: "bridge_unhandled_failure",
          message: `宿主机 Bridge 未处理失败：${errorMessage(error)}`,
          deliveryEvidence: latest.deliveryEvidence,
        })
      }
    } catch (updateError) {
      log("ERROR", "未处理失败无法写回；租约到期后任务将标记 unknown", {
        taskId: task.id,
        error: errorMessage(updateError),
      })
    }
  } finally {
    await leaseKeeper.stop()
    input.signal.removeEventListener("abort", parentAbortHandler)
  }
}

async function sendBridgeHeartbeat(client, config, input) {
  return client.heartbeat(
    {
      protocolVersion: PROTOCOL_VERSION,
      bridgeId: config.bridgeId,
      workerInstanceId: input.workerInstanceId,
      name: config.name,
      workerVersion: CONNECT_VERSION,
      codexVersion: input.codexVersion,
      workspaces: input.workspaces.map((workspace) => workspace.summary),
    },
    input.signal,
  )
}

export async function runCodexWorker(options = {}) {
  const environment = options.environment || process.env
  const releaseLock = await acquireProcessLock(environment)
  const stopController = new AbortController()
  const stop = (signalName) => {
    if (!stopController.signal.aborted) {
      log("INFO", `收到 ${signalName}，正在停止 Codex Bridge`)
      stopController.abort(new Error(`worker received ${signalName}`))
    }
  }
  const onSigint = () => stop("SIGINT")
  const onSigterm = () => stop("SIGTERM")
  process.once("SIGINT", onSigint)
  process.once("SIGTERM", onSigterm)
  try {
    const config = await readBridgeConfig({ environment })
    if (config.dockerBinary) {
      process.env.DOCKER_BINARY = config.dockerBinary
    }
    const dockerAvailable = config.dockerBinary
      ? await isDockerAvailable({
          dockerBinary: config.dockerBinary,
          environment,
        })
      : false
    const workspaces = await loadWorkspaces(config.workspacePaths, {
      environment,
      dockerBinary: config.dockerBinary,
      dockerAvailable,
    })
    const skillPath = await installCodexBridgeSkill({ environment })
    const codexVersion = await readCodexVersion({
      codexBinary: config.codexBinary,
    })
    await cleanupExpiredLocalPreviews()
    const client = new BridgeHttpClient({
      baseUrl: config.baseUrl,
      apiKey: config.apiKey,
    })
    const workerInstanceId = `worker_${randomUUID()}`
    let nextHeartbeatAt = 0
    log("INFO", "Codex Bridge 已启动", {
      bridgeId: config.bridgeId,
      workerInstanceId,
      workspaces: workspaces.map((workspace) => workspace.config.id),
    })
    while (!stopController.signal.aborted) {
      try {
        if (Date.now() >= nextHeartbeatAt) {
          await sendBridgeHeartbeat(client, config, {
            workerInstanceId,
            codexVersion,
            workspaces,
            signal: stopController.signal,
          })
          nextHeartbeatAt = Date.now() + HEARTBEAT_INTERVAL_MS
        }
        const rawClaim = await client.claim(
          { bridgeId: config.bridgeId, workerInstanceId },
          stopController.signal,
        )
        if (rawClaim?.task) {
          const claim = requireClaim(rawClaim)
          log("INFO", "领取 Codex 任务", {
            taskId: claim.task.id,
            workspaceId: claim.task.workspaceId,
          })
          await handleClaim(client, config, claim, {
            workerInstanceId,
            codexVersion,
            workspaces,
            environment,
            skillPath,
            signal: stopController.signal,
          })
          nextHeartbeatAt = 0
          continue
        }
      } catch (error) {
        if (stopController.signal.aborted) break
        const retryAfterMs =
          error instanceof BridgeHttpError && error.retryAfterSeconds
            ? error.retryAfterSeconds * 1_000
            : CLAIM_INTERVAL_MS
        log("ERROR", "Bridge 心跳或领取失败；尚未领取的任务不会丢失", {
          error: errorMessage(error),
          retryAfterMs,
        })
        await sleep(retryAfterMs, stopController.signal).catch(() => undefined)
        continue
      }
      await sleep(CLAIM_INTERVAL_MS, stopController.signal).catch(
        () => undefined,
      )
    }
  } finally {
    process.removeListener("SIGINT", onSigint)
    process.removeListener("SIGTERM", onSigterm)
    await releaseLock()
  }
}
