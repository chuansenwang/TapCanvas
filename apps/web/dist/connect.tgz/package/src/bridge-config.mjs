import { randomUUID } from "node:crypto"
import { promises as fs } from "node:fs"
import os from "node:os"
import path from "node:path"
import { isPlainObject, requireNonEmptyString } from "./process-utils.mjs"

const BRIDGE_CONFIG_VERSION = 1

export function bridgeConfigPath(environment = process.env) {
  const override = environment.TAPCANVAS_BRIDGE_CONFIG
  return override
    ? path.resolve(override)
    : path.join(os.homedir(), ".tapcanvas", "codex-bridge.json")
}

export function normalizeBridgeBaseUrl(value) {
  const raw = requireNonEmptyString(value, "baseUrl", 2_000).replace(/\/+$/u, "")
  let parsed
  try {
    parsed = new URL(raw)
  } catch {
    throw new Error("baseUrl 必须是合法 URL")
  }
  if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
    throw new Error("baseUrl 只允许 http 或 https")
  }
  const loopbackHosts = new Set(["127.0.0.1", "localhost", "::1"])
  if (parsed.protocol === "http:" && !loopbackHosts.has(parsed.hostname)) {
    throw new Error("非本机 TapCanvas 地址必须使用 https")
  }
  return parsed.toString().replace(/\/+$/u, "")
}

function normalizeExecutablePath(value, field, nullable = false) {
  if (nullable && (value === null || typeof value === "undefined")) return null
  const resolved = requireNonEmptyString(value, field, 2_000)
  if (!path.isAbsolute(resolved)) {
    throw new Error(`${field} 必须是已解析的绝对可执行文件路径`)
  }
  return path.normalize(resolved)
}

function normalizeWorkspacePaths(value) {
  if (!Array.isArray(value) || value.length === 0 || value.length > 64) {
    throw new Error("workspacePaths 必须包含 1 到 64 个目录")
  }
  const paths = value.map((item, index) =>
    path.resolve(requireNonEmptyString(item, `workspacePaths[${index}]`, 2_000)),
  )
  return [...new Set(paths)]
}

export function parseBridgeConfig(value) {
  if (!isPlainObject(value) || value.version !== BRIDGE_CONFIG_VERSION) {
    throw new Error("Codex Bridge 配置 version 必须为 1")
  }
  return {
    version: BRIDGE_CONFIG_VERSION,
    bridgeId: requireNonEmptyString(value.bridgeId, "bridgeId", 120),
    name: requireNonEmptyString(value.name, "name", 120),
    baseUrl: normalizeBridgeBaseUrl(value.baseUrl),
    apiKey: requireNonEmptyString(value.apiKey, "apiKey", 2_000),
    codexBinary: normalizeExecutablePath(value.codexBinary, "codexBinary"),
    dockerBinary: normalizeExecutablePath(
      value.dockerBinary,
      "dockerBinary",
      true,
    ),
    workspacePaths: normalizeWorkspacePaths(value.workspacePaths),
  }
}

export async function readBridgeConfig(options = {}) {
  const file = bridgeConfigPath(options.environment || process.env)
  let raw
  try {
    raw = await fs.readFile(file, "utf8")
  } catch (error) {
    if (error && typeof error === "object" && error.code === "ENOENT") {
      throw new Error(
        `未找到 Codex Bridge 配置 ${file}；请回到 TapCanvas 画布点击“复制给 Codex”完成首次连接`,
      )
    }
    throw error
  }
  try {
    return parseBridgeConfig(JSON.parse(raw))
  } catch (error) {
    throw new Error(`Codex Bridge 配置无效：${error.message}`)
  }
}

async function readExistingConfigOrNull(file) {
  try {
    return parseBridgeConfig(JSON.parse(await fs.readFile(file, "utf8")))
  } catch (error) {
    if (error && typeof error === "object" && error.code === "ENOENT") return null
    throw error
  }
}

export async function saveBridgeConfig(input, options = {}) {
  const file = bridgeConfigPath(options.environment || process.env)
  const existing = await readExistingConfigOrNull(file)
  const workspacePaths = normalizeWorkspacePaths([
    ...(existing?.workspacePaths || []),
    ...input.workspacePaths,
  ])
  const config = parseBridgeConfig({
    version: BRIDGE_CONFIG_VERSION,
    bridgeId: existing?.bridgeId || `bridge_${randomUUID()}`,
    name: input.name || existing?.name || os.hostname(),
    baseUrl: input.baseUrl,
    apiKey: input.apiKey,
    codexBinary: input.codexBinary || existing?.codexBinary,
    dockerBinary:
      typeof input.dockerBinary === "undefined"
        ? existing?.dockerBinary
        : input.dockerBinary,
    workspacePaths,
  })
  await fs.mkdir(path.dirname(file), { recursive: true, mode: 0o700 })
  const temporaryFile = `${file}.${process.pid}.${randomUUID()}.tmp`
  await fs.writeFile(temporaryFile, `${JSON.stringify(config, null, 2)}\n`, {
    encoding: "utf8",
    mode: 0o600,
    flag: "wx",
  })
  await fs.chmod(temporaryFile, 0o600)
  await fs.rename(temporaryFile, file)
  await fs.chmod(file, 0o600)
  return { config, file }
}
