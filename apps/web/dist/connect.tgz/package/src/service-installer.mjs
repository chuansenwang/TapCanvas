import { randomUUID } from "node:crypto"
import { constants as fsConstants, promises as fs } from "node:fs"
import os from "node:os"
import path from "node:path"
import { fileURLToPath } from "node:url"
import { bridgeConfigPath } from "./bridge-config.mjs"
import { errorMessage, runProcess } from "./process-utils.mjs"
import { CONNECT_VERSION } from "./version.mjs"

const SERVICE_LABEL = "com.tapcanvas.codex-bridge"
const LINUX_SERVICE_NAME = "tapcanvas-codex-bridge.service"

function packageRoot() {
  return path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..")
}

function runtimeBase(environment = process.env) {
  return environment.TAPCANVAS_CONNECT_RUNTIME_ROOT
    ? path.resolve(environment.TAPCANVAS_CONNECT_RUNTIME_ROOT)
    : path.join(os.homedir(), ".tapcanvas", "connect")
}

async function pathExists(file) {
  try {
    await fs.access(file)
    return true
  } catch {
    return false
  }
}

async function validateInstalledRuntime(destination) {
  const marker = path.join(destination, "runtime.json")
  let parsed
  try {
    parsed = JSON.parse(await fs.readFile(marker, "utf8"))
  } catch {
    throw new Error(
      `Codex Bridge runtime 目录已存在但版本标记不可读：${destination}`,
    )
  }
  if (parsed?.version !== CONNECT_VERSION) {
    throw new Error(`Codex Bridge runtime 版本标记不一致：${destination}`)
  }
  const workerEntrypoint = path.join(destination, "src", "cli.mjs")
  const workerStat = await fs.stat(workerEntrypoint).catch(() => null)
  if (!workerStat?.isFile()) {
    throw new Error(
      `Codex Bridge runtime 缺少 worker 入口：${workerEntrypoint}`,
    )
  }
  return { root: destination, workerEntrypoint }
}

async function atomicWrite(file, content, mode) {
  await fs.mkdir(path.dirname(file), { recursive: true, mode: 0o700 })
  const temporary = `${file}.${process.pid}.${randomUUID()}.tmp`
  await fs.writeFile(temporary, content, {
    encoding: "utf8",
    mode,
    flag: "wx",
  })
  await fs.chmod(temporary, mode)
  await fs.rename(temporary, file)
  await fs.chmod(file, mode)
}

export async function resolveExecutable(input, options = {}) {
  const name = String(input || "").trim()
  if (!name) throw new Error("可执行文件名不能为空")
  const environment = options.environment || process.env
  const candidates = []
  if (path.isAbsolute(name)) {
    candidates.push(path.normalize(name))
  } else {
    for (const directory of String(environment.PATH || "")
      .split(path.delimiter)
      .filter(Boolean)) {
      candidates.push(path.resolve(directory, name))
    }
  }
  for (const candidate of candidates) {
    try {
      await fs.access(candidate, fsConstants.X_OK)
      const stat = await fs.stat(candidate)
      if (stat.isFile()) return await fs.realpath(candidate)
    } catch {
      // Continue checking the explicit PATH candidates.
    }
  }
  throw new Error(`找不到可执行文件：${name}`)
}

export async function preflightPersistentBridgeService(options = {}) {
  const environment = options.environment || process.env
  const platform = options.platform || process.platform
  if (platform === "darwin") {
    const launchctl = await resolveExecutable("/bin/launchctl", {
      environment,
    })
    const uid = typeof process.getuid === "function" ? process.getuid() : null
    if (!Number.isInteger(uid) || uid < 0) {
      throw new Error("无法确定当前 macOS 用户 UID")
    }
    const result = await runProcess(launchctl, ["print", `gui/${uid}`], {
      timeoutMs: 10_000,
      env: environment,
    })
    if (result.exitCode !== 0) {
      throw new Error(
        `当前 macOS 图形用户会话不能注册 LaunchAgent：${result.stderr || result.stdout}`,
      )
    }
    return { kind: "launch-agent", executable: launchctl }
  }
  if (platform === "linux") {
    const systemctl = await resolveExecutable("systemctl", { environment })
    const result = await runProcess(
      systemctl,
      ["--user", "show-environment"],
      {
        timeoutMs: 10_000,
        env: environment,
      },
    )
    if (result.exitCode !== 0) {
      throw new Error(
        `当前 Linux 用户会话不能注册 systemd user 服务：${result.stderr || result.stdout}`,
      )
    }
    return { kind: "systemd-user", executable: systemctl }
  }
  throw new Error(
    `当前平台 ${platform} 暂不支持无人值守常驻服务；不会消耗一次性配对码`,
  )
}

export async function installStableRuntime(options = {}) {
  const environment = options.environment || process.env
  const destination = path.join(runtimeBase(environment), CONNECT_VERSION)
  if (await pathExists(destination)) {
    return validateInstalledRuntime(destination)
  }

  await fs.mkdir(path.dirname(destination), { recursive: true, mode: 0o700 })
  const temporary = `${destination}.${process.pid}.${randomUUID()}.tmp`
  try {
    await fs.mkdir(temporary, { recursive: false, mode: 0o700 })
    await fs.cp(path.join(packageRoot(), "src"), path.join(temporary, "src"), {
      recursive: true,
      errorOnExist: true,
      force: false,
    })
    await fs.copyFile(
      path.join(packageRoot(), "package.json"),
      path.join(temporary, "package.json"),
    )
    if (await pathExists(path.join(packageRoot(), "README.md"))) {
      await fs.copyFile(
        path.join(packageRoot(), "README.md"),
        path.join(temporary, "README.md"),
      )
    }
    await fs.writeFile(
      path.join(temporary, "runtime.json"),
      `${JSON.stringify(
        { version: CONNECT_VERSION, installedAt: new Date().toISOString() },
        null,
        2,
      )}\n`,
      { encoding: "utf8", mode: 0o600 },
    )
    await fs.rename(temporary, destination)
  } catch (error) {
    await fs.rm(temporary, { recursive: true, force: true })
    if (await pathExists(destination)) {
      return validateInstalledRuntime(destination)
    }
    throw error
  }
  return validateInstalledRuntime(destination)
}

function xmlEscape(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&apos;")
}

export function renderLaunchAgent(input) {
  const argumentsXml = input.arguments
    .map((argument) => `      <string>${xmlEscape(argument)}</string>`)
    .join("\n")
  const environmentXml = input.environmentVariables
    ? `    <key>EnvironmentVariables</key>\n    <dict>\n${Object.entries(input.environmentVariables)
        .map(([key, value]) => `      <key>${xmlEscape(key)}</key>\n      <string>${xmlEscape(value)}</string>`)
        .join("\n")}\n    </dict>\n`
    : ""
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
  <dict>
    <key>Label</key>
    <string>${SERVICE_LABEL}</string>
    <key>ProgramArguments</key>
    <array>
${argumentsXml}
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>ProcessType</key>
    <string>Background</string>
${environmentXml}    <key>WorkingDirectory</key>
    <string>${xmlEscape(input.workingDirectory)}</string>
    <key>StandardOutPath</key>
    <string>${xmlEscape(input.stdoutPath)}</string>
    <key>StandardErrorPath</key>
    <string>${xmlEscape(input.stderrPath)}</string>
  </dict>
</plist>
`
}

function systemdQuote(value) {
  return `"${String(value)
    .replaceAll("\\", "\\\\")
    .replaceAll('"', '\\"')
    .replaceAll("%", "%%")}"`
}

export function renderSystemdUserService(input) {
  const command = input.arguments.map(systemdQuote).join(" ")
  const environment = input.environmentVariables
    ? Object.entries(input.environmentVariables)
        .map(([key, value]) => `Environment=${systemdQuote(`${key}=${value}`)}`)
        .join("\n")
    : ""
  return `[Unit]
Description=TapCanvas Codex Bridge
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=${command}
${environment ? `${environment}\n` : ""}WorkingDirectory=${systemdQuote(input.workingDirectory)}
Restart=on-failure
RestartSec=5
StandardOutput=${systemdQuote(`append:${input.stdoutPath}`)}
StandardError=${systemdQuote(`append:${input.stderrPath}`)}

[Install]
WantedBy=default.target
`
}

async function runChecked(command, args, label, options = {}) {
  const result = await runProcess(command, args, {
    timeoutMs: options.timeoutMs || 30_000,
    env: options.environment || process.env,
  })
  if (result.exitCode !== 0) {
    throw new Error(
      `${label}失败（exit=${result.exitCode}）：${result.stderr || result.stdout}`,
    )
  }
  return result
}

async function installMacService(input) {
  const launchctl = await resolveExecutable("/bin/launchctl", input)
  const uid = typeof process.getuid === "function" ? process.getuid() : null
  if (!Number.isInteger(uid) || uid < 0) {
    throw new Error("无法确定当前 macOS 用户 UID")
  }
  const launchAgents = path.join(os.homedir(), "Library", "LaunchAgents")
  const file = path.join(launchAgents, `${SERVICE_LABEL}.plist`)
  const domain = `gui/${uid}`
  const serviceTarget = `${domain}/${SERVICE_LABEL}`
  const existing = await runProcess(launchctl, ["print", serviceTarget], {
    timeoutMs: 10_000,
  })
  if (existing.exitCode === 0) {
    await runChecked(
      launchctl,
      ["bootout", serviceTarget],
      "停止旧 Codex Bridge 服务",
    )
  }
  await atomicWrite(
    file,
    renderLaunchAgent({
      arguments: input.arguments,
      workingDirectory: os.homedir(),
      stdoutPath: input.stdoutPath,
      stderrPath: input.stderrPath,
      environmentVariables: input.environmentVariables,
    }),
    0o600,
  )
  await runChecked(
    launchctl,
    ["bootstrap", domain, file],
    "注册 Codex Bridge LaunchAgent",
  )
  await runChecked(
    launchctl,
    ["kickstart", "-k", serviceTarget],
    "启动 Codex Bridge LaunchAgent",
  )
  return { kind: "launch-agent", file }
}

async function installLinuxService(input) {
  const systemctl = await resolveExecutable("systemctl", input)
  const file = path.join(
    os.homedir(),
    ".config",
    "systemd",
    "user",
    LINUX_SERVICE_NAME,
  )
  await atomicWrite(
    file,
    renderSystemdUserService({
      arguments: input.arguments,
      workingDirectory: os.homedir(),
      stdoutPath: input.stdoutPath,
      stderrPath: input.stderrPath,
      environmentVariables: input.environmentVariables,
    }),
    0o600,
  )
  await runChecked(systemctl, ["--user", "daemon-reload"], "刷新 systemd user")
  await runChecked(
    systemctl,
    ["--user", "enable", "--now", LINUX_SERVICE_NAME],
    "启用 Codex Bridge systemd user 服务",
  )
  return { kind: "systemd-user", file }
}

export async function installPersistentBridgeService(input, options = {}) {
  await preflightPersistentBridgeService(options)
  const runtime = await installStableRuntime(options)
  const logs = path.join(os.homedir(), ".tapcanvas", "logs")
  await fs.mkdir(logs, { recursive: true, mode: 0o700 })
  const stdoutPath = path.join(logs, "codex-bridge.stdout.log")
  const stderrPath = path.join(logs, "codex-bridge.stderr.log")
  const argumentsList = [
    input.nodeBinary,
    runtime.workerEntrypoint,
    "worker",
    "--config",
    bridgeConfigPath(options.environment || process.env),
  ]
  const serviceInput = {
    ...options,
    arguments: argumentsList,
    stdoutPath,
    stderrPath,
    environmentVariables: {
      PATH: String((options.environment || process.env).PATH || ""),
    },
  }
  const platform = options.platform || process.platform
  let service
  if (platform === "darwin") {
    service = await installMacService(serviceInput)
  } else if (platform === "linux") {
    service = await installLinuxService(serviceInput)
  } else {
    throw new Error(
      `当前平台 ${platform} 暂不支持无人值守常驻服务；未静默改用前台进程`,
    )
  }
  return {
    runtime,
    service,
    stdoutPath,
    stderrPath,
  }
}

export function serviceInstallError(error) {
  return errorMessage(error)
}
