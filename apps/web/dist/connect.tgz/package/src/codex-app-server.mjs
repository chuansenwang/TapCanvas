import { spawn } from "node:child_process"
import { randomUUID } from "node:crypto"
import { createInterface } from "node:readline"
import {
  appendBoundedText,
  errorMessage,
  isPlainObject,
  runProcess,
} from "./process-utils.mjs"
import {
  CODEX_BRIDGE_SKILL_NAME,
} from "./codex-skill.mjs"
import { CONNECT_VERSION } from "./version.mjs"

const DEFAULT_TURN_TIMEOUT_MS = 45 * 60 * 1_000
const RESPONSE_TIMEOUT_MS = 30_000
const STDERR_LIMIT_BYTES = 64 * 1024
const DEFAULT_APP_SERVER_ARGS = ["app-server", "--listen", "stdio://"]
const STEERING_POLL_INTERVAL_MS = 750

const TURN_OUTPUT_SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["outcome", "message"],
  properties: {
    outcome: {
      type: "string",
      enum: [
        "workspace_changed",
        "needs_input",
        "response_only",
        "failed",
      ],
    },
    message: {
      type: "string",
      minLength: 1,
      maxLength: 16_000,
    },
  },
}

const TURN_OUTCOMES = new Set(TURN_OUTPUT_SCHEMA.properties.outcome.enum)

class AppServerRpcRejectedError extends Error {
  constructor(message) {
    super(message)
    this.name = "AppServerRpcRejectedError"
  }
}

function requireRecord(value, label) {
  if (!isPlainObject(value)) {
    throw new Error(`Codex App Server ${label} 不是对象`)
  }
  return value
}

function requireString(value, label) {
  if (typeof value !== "string" || !value.trim()) {
    throw new Error(`Codex App Server ${label} 缺失`)
  }
  return value
}

function responseError(value) {
  if (!isPlainObject(value)) return "未知 RPC 错误"
  const message =
    typeof value.message === "string" && value.message.trim()
      ? value.message.trim()
      : JSON.stringify(value)
  return message
}

function appServerCommand(options) {
  return (
    options.command ||
    options.codexBinary ||
    process.env.CODEX_BINARY ||
    "codex"
  )
}

function appServerArgs(options) {
  return options.args || DEFAULT_APP_SERVER_ARGS
}

function spawnAppServer(input, options) {
  return spawn(appServerCommand(options), appServerArgs(options), {
    cwd: input.workspaceRoot,
    env: options.environment || process.env,
    stdio: ["pipe", "pipe", "pipe"],
    shell: false,
  })
}

async function initializeAppServer(client, workerVersion) {
  await client.request("initialize", {
    clientInfo: {
      name: "tapcanvas-codex-bridge",
      title: "TapCanvas Codex Bridge",
      version: workerVersion || CONNECT_VERSION,
    },
    capabilities: {
      experimentalApi: true,
    },
  })
  client.notify("initialized")
}

class JsonLineRpcClient {
  constructor(child) {
    this.child = child
    this.nextId = 1
    this.pending = new Map()
    this.waiters = new Set()
    this.notificationSubscribers = new Set()
    this.stderr = ""
    this.closedError = null
    this.fatalRequestError = null

    child.stderr?.on("data", (chunk) => {
      this.stderr = appendBoundedText(this.stderr, chunk, STDERR_LIMIT_BYTES)
    })
    this.lines = createInterface({ input: child.stdout })
    this.lines.on("line", (line) => this.handleLine(line))
    child.on("error", (error) => this.closeWithError(error))
    child.on("close", (code, signal) => {
      if (this.closedError) return
      const detail = this.stderr.trim()
      this.closeWithError(
        new Error(
          `Codex App Server 已退出（code=${String(code)}, signal=${String(signal)}）${
            detail ? `：${detail}` : ""
          }`,
        ),
      )
    })
  }

  send(payload) {
    if (this.closedError) throw this.closedError
    this.child.stdin.write(`${JSON.stringify(payload)}\n`)
  }

  request(method, params, timeoutMs = RESPONSE_TIMEOUT_MS) {
    const id = this.nextId
    this.nextId += 1
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id)
        reject(new Error(`Codex App Server ${method} 响应超时`))
      }, timeoutMs)
      this.pending.set(id, { resolve, reject, timer, method })
      try {
        this.send({ id, method, params })
      } catch (error) {
        clearTimeout(timer)
        this.pending.delete(id)
        reject(error)
      }
    })
  }

  notify(method) {
    this.send({ method })
  }

  waitForNotification(method, predicate, timeoutMs) {
    return new Promise((resolve, reject) => {
      const waiter = {
        method,
        predicate,
        resolve,
        reject,
        timer: setTimeout(() => {
          this.waiters.delete(waiter)
          reject(new Error(`等待 Codex App Server ${method} 超时`))
        }, timeoutMs),
      }
      this.waiters.add(waiter)
    })
  }

  handleLine(line) {
    let message
    try {
      message = JSON.parse(line)
    } catch {
      this.closeWithError(
        new Error(`Codex App Server 输出了非法 JSONL：${line.slice(0, 500)}`),
      )
      return
    }
    if (!isPlainObject(message)) return

    if (
      Object.hasOwn(message, "id") &&
      typeof message.method === "string"
    ) {
      this.handleServerRequest(message)
      return
    }
    if (Object.hasOwn(message, "id")) {
      const pending = this.pending.get(Number(message.id))
      if (!pending) return
      this.pending.delete(Number(message.id))
      clearTimeout(pending.timer)
      if (Object.hasOwn(message, "error")) {
        pending.reject(
          new AppServerRpcRejectedError(
            `Codex App Server ${pending.method} 失败：${responseError(message.error)}`,
          ),
        )
      } else {
        pending.resolve(message.result)
      }
      return
    }
    if (typeof message.method !== "string") return
    for (const subscriber of this.notificationSubscribers) {
      subscriber(message.method, message.params)
    }
    for (const waiter of [...this.waiters]) {
      if (waiter.method !== message.method) continue
      let matches = false
      try {
        matches = waiter.predicate(message.params)
      } catch (error) {
        clearTimeout(waiter.timer)
        this.waiters.delete(waiter)
        waiter.reject(error)
        continue
      }
      if (!matches) continue
      clearTimeout(waiter.timer)
      this.waiters.delete(waiter)
      waiter.resolve(message.params)
    }
  }

  subscribeNotifications(subscriber) {
    this.notificationSubscribers.add(subscriber)
    return () => this.notificationSubscribers.delete(subscriber)
  }

  handleServerRequest(message) {
    const id = message.id
    const method = message.method
    const approvalMethods = new Set([
      "item/commandExecution/requestApproval",
      "item/fileChange/requestApproval",
    ])
    if (approvalMethods.has(method)) {
      this.send({ id, result: { decision: "cancel" } })
    } else {
      this.send({
        id,
        error: {
          code: -32001,
          message: `TapCanvas unattended worker cannot answer ${method}`,
        },
      })
    }
    this.fatalRequestError = new Error(
      `Codex App Server 请求了无人值守 worker 无法处理的交互：${method}`,
    )
    this.closeWithError(this.fatalRequestError)
  }

  closeWithError(error) {
    if (this.closedError) return
    this.closedError = error instanceof Error ? error : new Error(String(error))
    for (const pending of this.pending.values()) {
      clearTimeout(pending.timer)
      pending.reject(this.closedError)
    }
    this.pending.clear()
    for (const waiter of this.waiters) {
      clearTimeout(waiter.timer)
      waiter.reject(this.closedError)
    }
    this.waiters.clear()
  }

  close() {
    this.lines.close()
    if (!this.child.killed) this.child.kill("SIGTERM")
  }
}

function collectCompletedItem(params, state) {
  if (!isPlainObject(params) || !isPlainObject(params.item)) return
  const item = params.item
  if (item.type === "fileChange" && item.status === "completed" && Array.isArray(item.changes)) {
    for (const change of item.changes) {
      if (isPlainObject(change) && typeof change.path === "string" && change.path.trim()) {
        state.changedFiles.add(change.path.trim())
      }
    }
  }
  if (item.type === "agentMessage" && typeof item.text === "string" && item.text.trim()) {
    if (item.phase === "final_answer") {
      state.finalMessages.push(item.text.trim())
    } else if (item.phase === null || typeof item.phase === "undefined") {
      state.unknownPhaseMessages.push(item.text.trim())
    }
  }
}

function parseTurnOutcome(raw) {
  let parsed
  try {
    parsed = JSON.parse(raw)
  } catch (error) {
    throw new Error(
      `Codex 最终回复不符合结构化 outcome 契约：${errorMessage(error)}`,
    )
  }
  const record = requireRecord(parsed, "turn outcome")
  const keys = Object.keys(record).sort()
  if (keys.length !== 2 || keys[0] !== "message" || keys[1] !== "outcome") {
    throw new Error("Codex turn outcome 必须且只能包含 outcome 与 message")
  }
  const outcome = requireString(record.outcome, "turn outcome.outcome")
  if (!TURN_OUTCOMES.has(outcome)) {
    throw new Error(`Codex turn outcome 不受支持：${outcome}`)
  }
  const message = requireString(record.message, "turn outcome.message").trim()
  if (message.length > 16_000) {
    throw new Error("Codex turn outcome.message 超过 16000 字符")
  }
  return { outcome, message }
}

function taskPrompt(task, contextSnapshot) {
  return [
    "这是 TapCanvas 画布派发到本机 Codex 的真实实现任务。",
    "",
    `任务 ID：${task.id}`,
		`会话 ID：${task.sessionId}`,
		`会话回合：${task.turnSequence}`,
    `目标：${task.goal}`,
    "",
		"本回合不可变画布上下文快照（JSON，直接来自派发瞬间的真实持久化画布）：",
		JSON.stringify(contextSnapshot, null, 2),
    "",
		"请在当前已授权 workspace 中完成实现。上面的快照是本回合画布事实来源，不要调用小T重新转述同一批画布数据。",
		`若确需快照之外的画布事实或授权动作，只能使用已安装的 tapcanvas CLI；先运行 tapcanvas doctor --json，再按 tools list → tools schema --name <tool> → tools call --name <tool> 使用。当前 projectId=${contextSnapshot.projectId || ""}，flowId=${contextSnapshot.flowId || ""}，chapterId=${contextSnapshot.chapterId || ""}。禁止绕过 CLI 直调 /public/* 或改走平行 MCP。`,
    "本回合不要执行依赖安装、测试、构建、预览、部署或 Docker；Bridge 会在回合结束后用隔离执行器验证。",
		"不要调用交互式提问工具。若缺少必须由用户决定的信息，返回 needs_input，并在 message 中给出一个明确问题。",
		"若真实修改了 workspace，返回 workspace_changed；只回答说明且没有文件副作用时返回 response_only；无法继续时返回 failed。",
		"最终回复受 outputSchema 约束，必须只返回 outcome 与 message。message 要列出真实改变或明确阻塞，不要把方案、占位内容或静态 demo 当成交付。",
  ].join("\n")
}

function waitForSteeringPoll(signal) {
  return new Promise((resolve) => {
    if (signal.aborted) {
      resolve()
      return
    }
    const timer = setTimeout(resolve, STEERING_POLL_INTERVAL_MS)
    signal.addEventListener("abort", () => {
      clearTimeout(timer)
      resolve()
    }, { once: true })
  })
}

async function runSteeringLoop(input) {
  while (!input.signal.aborted) {
    const messages = await input.steering.claim(input.signal)
    if (!Array.isArray(messages)) {
      throw new Error("TapCanvas steering claim 返回了非数组消息")
    }
    for (const message of messages) {
      if (input.signal.aborted) return
      if (
        !isPlainObject(message) ||
        typeof message.id !== "string" ||
        !message.id.trim() ||
        typeof message.text !== "string" ||
        !message.text.trim()
      ) {
        throw new Error("TapCanvas steering claim 返回了非法消息")
      }
      let steerError = null
      try {
        await input.client.request("turn/steer", {
          threadId: input.threadId,
          expectedTurnId: input.turnId,
          input: [{ type: "text", text: message.text.trim() }],
          clientUserMessageId: `tapcanvas-steer-${message.id}`,
        })
      } catch (error) {
        steerError = error
      }
      if (steerError) {
		if (!(steerError instanceof AppServerRpcRejectedError)) {
		  await input.steering.acknowledge(
		    message,
		    "unknown",
		    `Codex App Server 的确认响应未到达，无法确认本条补充是否进入当前回合：${errorMessage(steerError)}`,
		    input.signal,
		  )
		  throw steerError
		}
        await input.steering.acknowledge(
          message,
          "rejected",
          `Codex App Server 未接收本条补充：${errorMessage(steerError)}`,
          input.signal,
        )
        continue
      }
      await input.steering.acknowledge(
        message,
        "delivered",
        "补充消息已由 Codex App Server 接收进入当前回合",
        input.signal,
      )
    }
    await waitForSteeringPoll(input.signal)
  }
}

function turnTimeout(environment) {
  const raw = Number(environment.CODEX_TURN_TIMEOUT_MS)
  if (typeof environment.CODEX_TURN_TIMEOUT_MS === "undefined") {
    return DEFAULT_TURN_TIMEOUT_MS
  }
  if (!Number.isInteger(raw) || raw < 60_000 || raw > 86_400_000) {
    throw new Error("CODEX_TURN_TIMEOUT_MS 必须是 60000 到 86400000 之间的整数")
  }
  return raw
}

function normalizeTurnStatus(value) {
  if (value === "completed" || value === "failed" || value === "interrupted") {
    return value
  }
  throw new Error(`Codex App Server 返回了非终态 turn.status：${String(value)}`)
}

export async function readCodexVersion(options = {}) {
  const command = options.codexBinary || process.env.CODEX_BINARY || "codex"
  const result = await runProcess(command, ["--version"], { timeoutMs: 10_000 })
  if (result.exitCode !== 0) {
    throw new Error(
      `无法运行 Codex CLI（${command} --version）：${result.stderr || result.stdout}`,
    )
  }
  return result.stdout.trim()
}

/**
 * 首次配对前的无写入协议探针。
 *
 * `codex --version` 只能证明二进制存在，不能证明当前版本支持 Bridge 实际使用的
 * App Server 初始化、临时 thread、sandbox 与 runtime workspace roots 契约。
 * 这里创建 read-only ephemeral thread 后立刻退出，不启动 turn、不修改 workspace。
 */
export async function probeCodexAppServer(input, options = {}) {
  const child = spawnAppServer(
    { workspaceRoot: input.workspaceRoot },
    options,
  )
  const client = new JsonLineRpcClient(child)
  try {
    await initializeAppServer(client, options.workerVersion)
    const threadResult = requireRecord(
      await client.request("thread/start", {
        cwd: input.workspaceRoot,
        approvalPolicy: "never",
        sandbox: "read-only",
        runtimeWorkspaceRoots: [input.workspaceRoot],
        developerInstructions:
          "TapCanvas pairing compatibility check only. Do not start a turn or modify files.",
        ephemeral: true,
      }),
      "thread/start probe result",
    )
    const thread = requireRecord(
      threadResult.thread,
      "thread/start probe thread",
    )
    return {
      threadId: requireString(thread.id, "probe thread.id"),
    }
  } catch (error) {
    const stderr = client.stderr.trim()
    throw new Error(
      `Codex App Server 首装兼容性检查失败：${errorMessage(error)}${
        stderr ? `；stderr: ${stderr}` : ""
      }`,
    )
  } finally {
    client.close()
  }
}

export async function runCodexTaskWithAppServer(input, options = {}) {
  const child = spawnAppServer(
    { workspaceRoot: input.workspace.root },
    options,
  )
  const client = new JsonLineRpcClient(child)
  const state = {
    changedFiles: new Set(),
    finalMessages: [],
    unknownPhaseMessages: [],
	completedTurns: new Map(),
  }
  const timeoutMs =
    options.timeoutMs || turnTimeout(options.environment || process.env)
  let unsubscribeNotifications = null
  const abortHandler = () => {
    client.closeWithError(
      options.signal?.reason instanceof Error
        ? options.signal.reason
        : new Error("Codex task execution was canceled"),
    )
    if (!child.killed) child.kill("SIGTERM")
  }

  try {
    if (options.signal?.aborted) abortHandler()
    else options.signal?.addEventListener("abort", abortHandler, { once: true })
    await initializeAppServer(client, options.workerVersion)

		const threadMethod = input.task.resumeThreadId
			? "thread/resume"
			: "thread/start"
		const threadResult = requireRecord(
			await client.request(threadMethod, input.task.resumeThreadId
				? {
						threadId: input.task.resumeThreadId,
						cwd: input.workspace.root,
						approvalPolicy: "never",
						sandbox: "workspace-write",
						runtimeWorkspaceRoots: [input.workspace.root],
						developerInstructions:
							"You are running as a TapCanvas host bridge. Edit only this workspace. Follow repository instructions. Never perform builds, installs, previews, deployments, Docker operations, Git history changes, or destructive user-data changes in this turn. Fail explicitly when required facts are missing.",
						excludeTurns: true,
					}
				: {
						cwd: input.workspace.root,
						approvalPolicy: "never",
						sandbox: "workspace-write",
						runtimeWorkspaceRoots: [input.workspace.root],
						developerInstructions:
							"You are running as a TapCanvas host bridge. Edit only this workspace. Follow repository instructions. Never perform builds, installs, previews, deployments, Docker operations, Git history changes, or destructive user-data changes in this turn. Fail explicitly when required facts are missing.",
						ephemeral: false,
					}),
			`${threadMethod} result`,
		)
		const thread = requireRecord(threadResult.thread, `${threadMethod} thread`)
		const threadId = requireString(thread.id, "thread.id")
		if (input.task.resumeThreadId && threadId !== input.task.resumeThreadId) {
			throw new Error(
				`Codex thread/resume 返回了不同 threadId：expected=${input.task.resumeThreadId}, actual=${threadId}`,
			)
		}
    unsubscribeNotifications = client.subscribeNotifications((method, params) => {
      if (
        method === "item/completed" &&
        isPlainObject(params) &&
        params.threadId === threadId
      ) {
        collectCompletedItem(params, state)
      }
		if (
		  method === "turn/completed" &&
		  isPlainObject(params) &&
		  params.threadId === threadId &&
		  isPlainObject(params.turn) &&
		  typeof params.turn.id === "string"
		) {
		  state.completedTurns.set(params.turn.id, params)
		}
    })

    const turnResult = requireRecord(
      await client.request("turn/start", {
        threadId,
        input: [
          {
            type: "skill",
            name: CODEX_BRIDGE_SKILL_NAME,
            path: input.skillPath,
          },
				{
					type: "text",
					text: taskPrompt(input.task, input.contextSnapshot),
				},
			],
			clientUserMessageId: `tapcanvas-${input.task.id}-${randomUUID()}`,
			outputSchema: TURN_OUTPUT_SCHEMA,
		}),
      "turn/start result",
    )
    const turn = requireRecord(turnResult.turn, "turn/start turn")
    const turnId = requireString(turn.id, "turn.id")

		const steeringController = new AbortController()
		let steeringError = null
		const steeringPromise = options.steering
			? runSteeringLoop({
					client,
					threadId,
					turnId,
					steering: options.steering,
					signal: steeringController.signal,
				}).catch((error) => {
					steeringError = error
					client.closeWithError(error)
				})
			: null
		let completedNotification
		try {
				completedNotification = state.completedTurns.get(turnId) ||
					await client.waitForNotification(
						"turn/completed",
						(candidate) =>
							isPlainObject(candidate) &&
							candidate.threadId === threadId &&
							isPlainObject(candidate.turn) &&
							candidate.turn.id === turnId,
						timeoutMs,
					)
		} finally {
			steeringController.abort()
			await steeringPromise
		}
		if (steeringError) throw steeringError
		const completedParams = requireRecord(
			completedNotification,
			"turn/completed params",
		)
    const completedTurn = requireRecord(
      completedParams.turn,
      "turn/completed turn",
    )
    if (Array.isArray(completedTurn.items)) {
      for (const item of completedTurn.items) {
        collectCompletedItem(
          { threadId, turnId, item },
          state,
        )
      }
    }
    const status = normalizeTurnStatus(completedTurn.status)
		const rawSummary =
			state.finalMessages.at(-1) ||
      state.unknownPhaseMessages.at(-1) ||
      (isPlainObject(completedTurn.error) &&
      typeof completedTurn.error.message === "string"
        ? completedTurn.error.message
        : "")

		const parsedOutcome = status === "completed"
			? parseTurnOutcome(rawSummary)
			: {
					outcome: "failed",
					message: rawSummary || `Codex turn 以 ${status} 结束`,
				}

		return {
			threadId,
			turnId,
			status,
			outcome: parsedOutcome.outcome,
			changedFiles: [...state.changedFiles].sort(),
			summary: parsedOutcome.message,
		}
  } catch (error) {
    const stderr = client.stderr.trim()
    throw new Error(
      `Codex App Server 执行失败：${errorMessage(error)}${stderr ? `；stderr: ${stderr}` : ""}`,
    )
  } finally {
    options.signal?.removeEventListener("abort", abortHandler)
    unsubscribeNotifications?.()
    client.close()
  }
}
