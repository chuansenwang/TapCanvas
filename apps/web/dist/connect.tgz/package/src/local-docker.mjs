import { spawn } from "node:child_process"
import { createHash, randomUUID } from "node:crypto"
import { promises as fs } from "node:fs"
import os from "node:os"
import path from "node:path"
import {
  appendBoundedText,
  errorMessage,
  runProcess,
  sleep,
} from "./process-utils.mjs"

const LOG_LIMIT_BYTES = 256 * 1024
const LOG_TAIL_LENGTH = 16_000
const CONTAINER_ID_PATTERN = /^[a-f0-9]{12,64}$/u

export class LocalDockerBuildFailure extends Error {
  constructor(message, executionId, commands) {
    super(message)
    this.name = "LocalDockerBuildFailure"
    this.executionId = executionId
    this.commands = commands
  }
}

function dockerBinary() {
  return process.env.DOCKER_BINARY || "docker"
}

function redact(text, environment) {
  let output = text
  const values = [...new Set(Object.values(environment))]
    .filter(Boolean)
    .sort((left, right) => right.length - left.length)
  for (const value of values) {
    output = output.split(value).join("[REDACTED]")
  }
  return output
}

function evidence(input) {
  const log = redact(input.log, input.environment)
  return {
    name: input.name,
    executor: "local-docker",
    exitCode: input.exitCode,
    startedAt: input.startedAt,
    completedAt: input.completedAt,
    logSha256: createHash("sha256").update(log).digest("hex"),
    logTail: log.slice(-LOG_TAIL_LENGTH),
  }
}

async function docker(args, options = {}) {
  return runProcess(dockerBinary(), args, {
    timeoutMs: options.timeoutMs || 30_000,
    logLimitBytes: LOG_LIMIT_BYTES,
    signal: options.signal,
  })
}

async function requireDockerSuccess(args, label, options = {}) {
  const result = await docker(args, options)
  if (result.exitCode !== 0) {
    throw new Error(
      `${label} 失败（exit=${result.exitCode}）：${result.stderr || result.stdout}`,
    )
  }
  return result
}

function safeContainerName(taskId) {
  const normalized = String(taskId)
    .toLowerCase()
    .replace(/[^a-z0-9_.-]/gu, "-")
    .slice(0, 80)
  return `tc-codex-${normalized || randomUUID()}`
}

async function writeEnvironmentFile(environment) {
  const directory = await fs.mkdtemp(
    path.join(os.tmpdir(), "tapcanvas-codex-docker-env-"),
  )
  const file = path.join(directory, "environment")
  const lines = []
  for (const [name, value] of Object.entries(environment)) {
    if (/[\0\r\n]/u.test(value)) {
      await fs.rm(directory, { recursive: true, force: true })
      throw new Error(`环境变量 ${name} 含 Docker env-file 不支持的换行或 NUL`)
    }
    lines.push(`${name}=${value}`)
  }
  await fs.writeFile(file, `${lines.join("\n")}\n`, {
    mode: 0o600,
    encoding: "utf8",
  })
  return {
    file,
    async cleanup() {
      await fs.rm(directory, { recursive: true, force: true })
    },
  }
}

async function runBuildCommand(input) {
  const startedAt = new Date().toISOString()
  const result = await docker(
    [
      "exec",
      "--user",
      "1000:1000",
      "--workdir",
      "/workspace",
      input.containerName,
      input.argv[0],
      ...input.argv.slice(1),
    ],
    { timeoutMs: input.timeoutMs, signal: input.signal },
  )
  const commandEvidence = evidence({
    name: input.name,
    exitCode: result.exitCode,
    startedAt,
    completedAt: new Date().toISOString(),
    log: `${result.stdout}${result.stderr}`,
    environment: input.environment,
  })
  input.commands.push(commandEvidence)
  if (result.exitCode !== 0) {
    throw new Error(
      `${input.name} command exited with code ${result.exitCode}: ${commandEvidence.logTail}`,
    )
  }
}

function startPreviewProcess(input) {
  const args = [
    "exec",
    "--user",
    "1000:1000",
    "--workdir",
    "/workspace",
    input.containerName,
    input.argv[0],
    ...input.argv.slice(1),
  ]
  const child = spawn(dockerBinary(), args, {
    stdio: ["ignore", "pipe", "pipe"],
    shell: false,
  })
  let log = ""
  let exit = null
  child.stdout.on("data", (chunk) => {
    log = appendBoundedText(log, chunk, LOG_LIMIT_BYTES)
  })
  child.stderr.on("data", (chunk) => {
    log = appendBoundedText(log, chunk, LOG_LIMIT_BYTES)
  })
  child.once("error", (error) => {
    exit = { exitCode: -1, error: errorMessage(error) }
  })
  child.once("close", (code) => {
    exit = { exitCode: typeof code === "number" ? code : -1, error: "" }
  })
  const abortHandler = () => child.kill("SIGTERM")
  if (input.signal?.aborted) abortHandler()
  else input.signal?.addEventListener("abort", abortHandler, { once: true })
  return {
    readExit: () => exit,
    readLog: () => log,
    detach() {
      input.signal?.removeEventListener("abort", abortHandler)
      child.stdout.destroy()
      child.stderr.destroy()
      child.unref()
    },
  }
}

async function resolveHostPort(containerName, previewPort) {
  const result = await requireDockerSuccess(
    ["port", containerName, `${previewPort}/tcp`],
    "读取 Docker preview 端口",
  )
  const line = result.stdout.trim().split(/\r?\n/u)[0] || ""
  const separator = line.lastIndexOf(":")
  const host = separator > 0 ? line.slice(0, separator) : ""
  const port = Number(separator > 0 ? line.slice(separator + 1) : "")
  if (host !== "127.0.0.1" || !Number.isInteger(port) || port < 1_024 || port > 65_535) {
    throw new Error(`Docker preview 端口映射不安全或无法解析：${line}`)
  }
  return port
}

async function waitForLocalPreview(input) {
  const preview = startPreviewProcess({
    containerName: input.containerName,
    argv: input.spec.commands.preview,
    signal: input.signal,
  })
  const startedAt = new Date().toISOString()
  const port = await resolveHostPort(
    input.containerName,
    input.spec.previewPort,
  )
  const baseUrl = `http://127.0.0.1:${port}`
  const readyUrl = new URL(input.spec.previewReadyPath, baseUrl).toString()
  const deadline = Date.now() + input.spec.previewReadyTimeoutMs
  let lastStatus = null
  let lastError = ""
  while (Date.now() < deadline) {
    if (input.signal?.aborted) {
      throw input.signal.reason instanceof Error
        ? input.signal.reason
        : new Error("local Docker preview 已取消")
    }
    const exited = preview.readExit()
    if (exited) {
      const commandEvidence = evidence({
        name: "preview",
        exitCode: exited.exitCode,
        startedAt,
        completedAt: new Date().toISOString(),
        log: `${preview.readLog()}\n${exited.error}`,
        environment: input.environment,
      })
      input.commands.push(commandEvidence)
      throw new Error(
        `local Docker preview exited before readiness with code ${exited.exitCode}`,
      )
    }
    try {
      const response = await fetch(readyUrl, {
        signal: AbortSignal.timeout(5_000),
      })
      lastStatus = response.status
      if (response.ok) {
        input.commands.push(
          evidence({
            name: "preview",
            exitCode: 0,
            startedAt,
            completedAt: new Date().toISOString(),
            log: preview.readLog(),
            environment: input.environment,
          }),
        )
        preview.detach()
        return baseUrl
      }
    } catch (error) {
      lastError = errorMessage(error)
    }
    await sleep(500)
  }
  input.commands.push(
    evidence({
      name: "preview",
      exitCode: -1,
      startedAt,
      completedAt: new Date().toISOString(),
      log: `${preview.readLog()}\nlastStatus=${String(lastStatus)}\nlastError=${lastError}`,
      environment: input.environment,
    }),
  )
  throw new Error(
    `local Docker preview 未在 ${input.spec.previewReadyTimeoutMs}ms 内就绪`,
  )
}

export async function cleanupExpiredLocalPreviews(nowMs = Date.now()) {
  const listed = await docker([
    "ps",
    "-a",
    "--filter",
    "label=tapcanvas.codex.preview=true",
    "--format",
    '{{.ID}}|{{.Label "tapcanvas.codex.expires-at"}}',
  ]).catch(() => null)
  if (!listed || listed.exitCode !== 0) return
  for (const line of listed.stdout.split(/\r?\n/u)) {
    const [containerId, expiresAtRaw] = line.trim().split("|")
    const expiresAt = Number(expiresAtRaw)
    if (
      !CONTAINER_ID_PATTERN.test(containerId || "") ||
      !Number.isFinite(expiresAt) ||
      expiresAt > nowMs
    ) {
      continue
    }
    await docker(["rm", "-f", containerId], { timeoutMs: 30_000 }).catch(
      (error) => {
        process.stderr.write(
          `[tapcanvas-connect] 清理过期 preview ${containerId} 失败：${errorMessage(error)}\n`,
        )
      },
    )
  }
}

export async function runLocalDockerBuild(input) {
  const local = input.workspace.config.localDocker
  if (!local) {
    throw new Error("workspace 未配置 localDocker，不能执行本机 fallback")
  }
  const commands = []
  const containerName = safeContainerName(input.task.id)
  const expiresAtMs = Date.now() + local.timeoutMs
  const environmentFile = await writeEnvironmentFile(input.workspace.environment)
  let containerCreated = false
  let keepContainer = false
  try {
    await requireDockerSuccess(
      [
        "create",
        "--name",
        containerName,
        "--label",
        "tapcanvas.codex.preview=true",
        "--label",
        `tapcanvas.codex.task=${input.task.id}`,
        "--label",
        `tapcanvas.codex.expires-at=${expiresAtMs}`,
        "--read-only",
        "--tmpfs",
        "/workspace:rw,nosuid,nodev,uid=1000,gid=1000,mode=0770",
        "--tmpfs",
        "/tmp:rw,nosuid,nodev,uid=1000,gid=1000,mode=1770",
        "--tmpfs",
        "/home/node:rw,nosuid,nodev,uid=1000,gid=1000,mode=0700",
        "--cap-drop",
        "ALL",
        "--security-opt",
        "no-new-privileges",
        "--pids-limit",
        String(local.pidsLimit),
        "--memory",
        `${local.memoryMb}m`,
        "--cpus",
        String(local.cpus),
        "--user",
        "1000:1000",
        "--env-file",
        environmentFile.file,
        "--publish",
        `127.0.0.1::${input.workspace.config.previewPort}/tcp`,
        local.image,
        "node",
        "-e",
        "setInterval(() => {}, 2147483647)",
      ],
      "创建隔离 Docker 容器",
      { timeoutMs: 10 * 60 * 1_000, signal: input.signal },
    )
    containerCreated = true
    await requireDockerSuccess(
      ["start", containerName],
      "启动隔离 Docker 容器",
      { signal: input.signal },
    )
    await requireDockerSuccess(
      ["cp", input.archive.archivePath, `${containerName}:/tmp/source.tgz`],
      "复制源码归档到 Docker",
      { timeoutMs: 5 * 60 * 1_000, signal: input.signal },
    )
    await requireDockerSuccess(
      [
        "exec",
        "--user",
        "1000:1000",
        containerName,
        "tar",
        "-xzf",
        "/tmp/source.tgz",
        "-C",
        "/workspace",
      ],
      "在 Docker 中解包源码",
      { timeoutMs: 5 * 60 * 1_000, signal: input.signal },
    )

    for (const name of ["install", "test", "build"]) {
      await runBuildCommand({
        name,
        argv: input.workspace.config.commands[name],
        containerName,
        timeoutMs: local.timeoutMs,
        environment: input.workspace.environment,
        commands,
        signal: input.signal,
      })
    }
    await requireDockerSuccess(
      [
        "exec",
        "--user",
        "1000:1000",
        "--workdir",
        "/workspace",
        containerName,
        "test",
        "-d",
        input.workspace.config.outputDirectory,
      ],
      "验证 Docker 构建产物目录",
      { signal: input.signal },
    )
    const url = await waitForLocalPreview({
      containerName,
      spec: {
        commands: input.workspace.config.commands,
        previewPort: input.workspace.config.previewPort,
        previewReadyPath: input.workspace.config.previewReadyPath,
        previewReadyTimeoutMs:
          input.workspace.config.previewReadyTimeoutMs,
      },
      environment: input.workspace.environment,
      commands,
      signal: input.signal,
    })
    keepContainer = true
    const expiryTimer = setTimeout(() => {
      void docker(["rm", "-f", containerName], {
        timeoutMs: 30_000,
      })
    }, Math.max(1_000, expiresAtMs - Date.now()))
    expiryTimer.unref()
    return {
      executionId: containerName,
      commands,
      preview: {
        previewId: input.task.previewId,
        url,
        expiresAt: new Date(expiresAtMs).toISOString(),
        isolatedOrigin: true,
      },
    }
  } catch (error) {
    if (error instanceof LocalDockerBuildFailure) throw error
    throw new LocalDockerBuildFailure(
      errorMessage(error),
      containerName,
      commands,
    )
  } finally {
    await environmentFile.cleanup()
    if (containerCreated && !keepContainer) {
      await docker(["rm", "-f", containerName], {
        timeoutMs: 30_000,
      }).catch(() => undefined)
    }
  }
}
