export const TAPCANVAS_CONFIG_VERSION = 2
export const TAPCANVAS_PROFILE_NAMES = Object.freeze(["local", "production"])

function isRecord(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value)
}

export function normalizeTapCanvasProfile(value) {
  const profile = String(value || "").trim()
  if (!TAPCANVAS_PROFILE_NAMES.includes(profile)) {
    throw new Error("必须显式选择 --profile local 或 --profile production")
  }
  return profile
}

export function resolveTapCanvasProfile(args, environment = process.env) {
  return normalizeTapCanvasProfile(
    argsProfileValue(args) || environment.TAPCANVAS_PROFILE,
  )
}

function argsProfileValue(args) {
  if (typeof args === "string") return args
  if (!args || typeof args !== "object") return ""
  return String(args.profile || "")
}

function isLoopbackHostname(hostname) {
  const normalized = hostname.toLowerCase().replace(/^\[|\]$/gu, "")
  return normalized === "localhost" || normalized === "::1" || normalized.startsWith("127.")
}

export function normalizeProfileApiBaseUrl(profileValue, value) {
  const profile = normalizeTapCanvasProfile(profileValue)
  const normalized = String(value || "").trim().replace(/\/+$/u, "")
  if (!normalized) throw new Error(`TapCanvas ${profile} profile 缺少 apiBaseUrl`)

  let parsed
  try {
    parsed = new URL(normalized)
  } catch {
    throw new Error(`TapCanvas ${profile} profile 的 apiBaseUrl 不是合法 URL`)
  }
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new Error(`TapCanvas ${profile} profile 的 apiBaseUrl 只允许 HTTP(S)`)
  }
  const loopback = isLoopbackHostname(parsed.hostname)
  if (profile === "local" && !loopback) {
    throw new Error("TapCanvas local profile 只允许 localhost、127.0.0.0/8 或 ::1")
  }
  if (profile === "production" && (loopback || parsed.protocol !== "https:")) {
    throw new Error("TapCanvas production profile 必须使用非 loopback HTTPS 地址")
  }
  return normalized
}

export function parseTapCanvasConfig(value, file) {
  if (!isRecord(value)) {
    throw new Error(`TapCanvas CLI 配置不是 JSON 对象：${file}`)
  }
  if (value.version !== TAPCANVAS_CONFIG_VERSION) {
    throw new Error(
      `TapCanvas CLI 配置版本不受支持：${file}；需要 version=${TAPCANVAS_CONFIG_VERSION}`,
    )
  }
  if (!isRecord(value.profiles)) {
    throw new Error(`TapCanvas CLI 配置缺少 profiles：${file}`)
  }
  return value
}

export function resolveTapCanvasCredentials(input) {
  const profile = normalizeTapCanvasProfile(input.profile)
  const document = parseTapCanvasConfig(input.document, input.file)
  const stored = document.profiles[profile]
  if (!isRecord(stored)) {
    throw new Error(`TapCanvas CLI 尚未配置 ${profile} profile：${input.file}`)
  }
  const environment = input.environment || process.env
  const overrides = isRecord(input.overrides) ? input.overrides : {}
  const apiBaseUrl = normalizeProfileApiBaseUrl(
    profile,
    overrides.apiBaseUrl || stored.apiBaseUrl || environment.TAPCANVAS_API_BASE_URL,
  )
  const apiKey = String(
    overrides.apiKey || stored.apiKey || environment.TAPCANVAS_API_KEY || "",
  ).trim()
  const authToken = String(
    overrides.authToken || stored.authToken || environment.TAPCANVAS_AUTH_TOKEN || "",
  ).trim()
  if (!apiKey && !authToken) {
    throw new Error(`TapCanvas ${profile} profile 缺少认证凭据：${input.file}`)
  }
  if (input.requireApiKey && !apiKey) {
    throw new Error(`TapCanvas ${profile} profile 缺少 apiKey：${input.file}`)
  }
  return { profile, apiBaseUrl, apiKey, authToken }
}

export function createTapCanvasConfigWithProfile(input) {
  const profile = normalizeTapCanvasProfile(input.profile)
  const apiBaseUrl = normalizeProfileApiBaseUrl(profile, input.apiBaseUrl)
  const apiKey = String(input.apiKey || "").trim()
  const authToken = String(input.authToken || "").trim()
  if (!apiKey && !authToken) {
    throw new Error(`TapCanvas ${profile} profile 至少需要 apiKey 或 authToken`)
  }
  const current = input.current === null || input.current === undefined
    ? { version: TAPCANVAS_CONFIG_VERSION, profiles: {} }
    : parseTapCanvasConfig(input.current, input.file)
  return {
    version: TAPCANVAS_CONFIG_VERSION,
    profiles: {
      ...current.profiles,
      [profile]: {
        apiBaseUrl,
        ...(apiKey ? { apiKey } : {}),
        ...(authToken ? { authToken } : {}),
      },
    },
  }
}

export function describeTapCanvasProfiles(value, file) {
  const document = parseTapCanvasConfig(value, file)
  return TAPCANVAS_PROFILE_NAMES.map((profile) => {
    const configured = document.profiles[profile]
    if (!isRecord(configured)) {
      return { profile, configured: false }
    }
    return {
      profile,
      configured: true,
      apiBaseUrl: normalizeProfileApiBaseUrl(profile, configured.apiBaseUrl),
      hasApiKey: Boolean(String(configured.apiKey || "").trim()),
      hasAuthToken: Boolean(String(configured.authToken || "").trim()),
    }
  })
}

export function profileForApiBaseUrl(value) {
  const normalized = String(value || "").trim().replace(/\/+$/u, "")
  let parsed
  try {
    parsed = new URL(normalized)
  } catch {
    throw new Error("TapCanvas API base URL 不是合法 URL")
  }
  return isLoopbackHostname(parsed.hostname) ? "local" : "production"
}

export function buildTapCanvasApiUrl(input) {
  const profile = normalizeTapCanvasProfile(input.profile)
  const apiBaseUrl = normalizeProfileApiBaseUrl(profile, input.apiBaseUrl)
  const pathname = String(input.pathname || "").trim()
  if (!pathname.startsWith("/")) {
    throw new Error("TapCanvas API pathname 必须以 / 开头")
  }
  const prefix = profile === "production" && input.access === "protected"
    ? "/api"
    : ""
  return `${apiBaseUrl}${prefix}${pathname}`
}
