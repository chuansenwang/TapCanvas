import { spawn } from "node:child_process"
import { createHash } from "node:crypto"

const DEFAULT_LOG_LIMIT_BYTES = 128 * 1024

export function isPlainObject(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value)
}

export function requireNonEmptyString(value, field, maxLength = 10_000) {
  if (typeof value !== "string" || !value.trim()) {
    throw new Error(`${field} 必须是非空字符串`)
  }
  if (value.length > maxLength) {
    throw new Error(`${field} 超过最大长度 ${maxLength}`)
  }
  if (value.includes("\0")) {
    throw new Error(`${field} 不允许包含 NUL 字符`)
  }
  return value.trim()
}

export function requireIntegerInRange(value, field, minimum, maximum) {
  if (!Number.isInteger(value) || value < minimum || value > maximum) {
    throw new Error(`${field} 必须是 ${minimum} 到 ${maximum} 之间的整数`)
  }
  return value
}

export function requireFiniteInRange(value, field, minimum, maximum) {
  if (!Number.isFinite(value) || value < minimum || value > maximum) {
    throw new Error(`${field} 必须是 ${minimum} 到 ${maximum} 之间的数值`)
  }
  return value
}

export function requireArgv(value, field) {
  if (!Array.isArray(value) || value.length === 0 || value.length > 64) {
    throw new Error(`${field} 必须是含 1 到 64 项的 argv 数组`)
  }
  return value.map((item, index) =>
    requireNonEmptyString(item, `${field}[${index}]`, 2_000),
  )
}

export function sha256(value) {
  return createHash("sha256").update(value).digest("hex")
}

export function appendBoundedText(current, chunk, maximumBytes = DEFAULT_LOG_LIMIT_BYTES) {
  const combined = `${current}${String(chunk)}`
  const bytes = Buffer.byteLength(combined)
  if (bytes <= maximumBytes) return combined
  const buffer = Buffer.from(combined)
  return buffer.subarray(buffer.length - maximumBytes).toString("utf8")
}

export function commandDisplay(argv) {
  return argv
    .map((part) => (/[^\w@%+=:,./-]/u.test(part) ? JSON.stringify(part) : part))
    .join(" ")
}

export function runProcess(command, args = [], options = {}) {
  const {
    cwd,
    env,
    input,
    signal,
    timeoutMs = 0,
    logLimitBytes = DEFAULT_LOG_LIMIT_BYTES,
    stdio = "pipe",
  } = options

  return new Promise((resolve, reject) => {
    let child
    try {
      child = spawn(command, args, {
        cwd,
        env,
        stdio,
        shell: false,
      })
    } catch (error) {
      reject(error)
      return
    }

    let stdout = ""
    let stderr = ""
    let settled = false
    let timedOut = false
    const abortHandler = () => {
      child.kill("SIGTERM")
    }
    const timer =
      timeoutMs > 0
        ? setTimeout(() => {
            timedOut = true
            child.kill("SIGKILL")
          }, timeoutMs)
        : null

    if (signal?.aborted) {
      abortHandler()
    } else {
      signal?.addEventListener("abort", abortHandler, { once: true })
    }

    if (child.stdout) {
      child.stdout.on("data", (chunk) => {
        stdout = appendBoundedText(stdout, chunk, logLimitBytes)
      })
    }
    if (child.stderr) {
      child.stderr.on("data", (chunk) => {
        stderr = appendBoundedText(stderr, chunk, logLimitBytes)
      })
    }
    child.on("error", (error) => {
      if (settled) return
      settled = true
      if (timer) clearTimeout(timer)
      signal?.removeEventListener("abort", abortHandler)
      reject(error)
    })
    child.on("close", (code, signal) => {
      if (settled) return
      settled = true
      if (timer) clearTimeout(timer)
      signal?.removeEventListener("abort", abortHandler)
      resolve({
        exitCode: typeof code === "number" ? code : -1,
        signal: signal || null,
        stdout,
        stderr,
        timedOut,
      })
    })

    if (typeof input === "string" || Buffer.isBuffer(input)) {
      child.stdin?.end(input)
    } else if (child.stdin) {
      child.stdin.end()
    }
  })
}

export async function sleep(ms, signal) {
  if (signal?.aborted) throw signal.reason || new Error("操作已取消")
  await new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, ms)
    if (!signal) return
    signal.addEventListener(
      "abort",
      () => {
        clearTimeout(timer)
        reject(signal.reason || new Error("操作已取消"))
      },
      { once: true },
    )
  })
}

export function errorMessage(error) {
  return error instanceof Error ? error.message : String(error)
}
