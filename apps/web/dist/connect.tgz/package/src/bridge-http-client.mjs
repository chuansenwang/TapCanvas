import { errorMessage } from "./process-utils.mjs"
import { createReadStream } from "node:fs"

export class BridgeHttpError extends Error {
  constructor(message, options = {}) {
    super(message)
    this.name = "BridgeHttpError"
    this.status = options.status || 0
    this.code = options.code || "bridge_http_error"
    this.retryAfterSeconds = options.retryAfterSeconds || null
  }
}

function publicCodexUrl(baseUrl, suffix) {
  return `${baseUrl.replace(/\/+$/u, "")}/public/codex${suffix}`
}

async function parseResponse(response) {
  const text = await response.text()
  if (!text) return null
  try {
    return JSON.parse(text)
  } catch {
    throw new BridgeHttpError(
      `TapCanvas 返回了非 JSON 响应（HTTP ${response.status}）`,
      { status: response.status, code: "invalid_json_response" },
    )
  }
}

function responseErrorMessage(body, response) {
  if (body && typeof body === "object") {
    if (typeof body.message === "string" && body.message) return body.message
    if (typeof body.error === "string" && body.error) return body.error
  }
  return `TapCanvas 请求失败（HTTP ${response.status}）`
}

export class BridgeHttpClient {
  constructor({ baseUrl, apiKey, fetchImpl = globalThis.fetch }) {
    if (typeof fetchImpl !== "function") {
      throw new Error("当前 Node 运行时没有 fetch；Codex worker 需要 Node 18+")
    }
    this.baseUrl = baseUrl.replace(/\/+$/u, "")
    this.apiKey = apiKey
    this.fetchImpl = fetchImpl
  }

  async request(method, suffix, body, signal) {
    let response
    try {
      response = await this.fetchImpl(publicCodexUrl(this.baseUrl, suffix), {
        method,
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          Accept: "application/json",
          ...(typeof body === "undefined"
            ? {}
            : { "Content-Type": "application/json" }),
        },
        body: typeof body === "undefined" ? undefined : JSON.stringify(body),
        signal,
      })
    } catch (error) {
      throw new BridgeHttpError(`无法连接 TapCanvas：${errorMessage(error)}`, {
        code: "network_error",
      })
    }
    const parsed = await parseResponse(response)
    if (!response.ok) {
      throw new BridgeHttpError(responseErrorMessage(parsed, response), {
        status: response.status,
        code:
          parsed && typeof parsed === "object" && typeof parsed.code === "string"
            ? parsed.code
            : "http_error",
        retryAfterSeconds: Number(response.headers.get("retry-after")) || null,
      })
    }
    return parsed
  }

  heartbeat(payload, signal) {
    return this.request("POST", "/bridges/heartbeat", payload, signal)
  }

  bridgeStatus(bridgeId, signal) {
    return this.request(
      "GET",
      `/bridges/self?bridgeId=${encodeURIComponent(bridgeId)}`,
      undefined,
      signal,
    )
  }

  claim(payload, signal) {
    return this.request("POST", "/tasks/claim", payload, signal)
  }

  getTask(taskId, signal) {
    return this.request("GET", `/tasks/${encodeURIComponent(taskId)}`, undefined, signal)
  }

  heartbeatLease(taskId, payload, signal) {
    return this.request(
      "POST",
      `/tasks/${encodeURIComponent(taskId)}/lease`,
      payload,
      signal,
    )
  }

  claimTaskMessages(taskId, payload, signal) {
    return this.request(
      "POST",
      `/tasks/${encodeURIComponent(taskId)}/messages/claim`,
      payload,
      signal,
    )
  }

  acknowledgeTaskMessage(taskId, payload, signal) {
    return this.request(
      "POST",
      `/tasks/${encodeURIComponent(taskId)}/messages/ack`,
      payload,
      signal,
    )
  }

  requestSourceUpload(taskId, payload, signal) {
    return this.request(
      "POST",
      `/tasks/${encodeURIComponent(taskId)}/source-upload`,
      payload,
      signal,
    )
  }

  enqueueRemoteBuild(taskId, payload, signal) {
    return this.request(
      "POST",
      `/tasks/${encodeURIComponent(taskId)}/remote-build`,
      payload,
      signal,
    )
  }

  discardSource(taskId, payload, signal) {
    return this.request(
      "POST",
      `/tasks/${encodeURIComponent(taskId)}/source-discard`,
      payload,
      signal,
    )
  }

  updateTask(taskId, payload, signal) {
    return this.request(
      "POST",
      `/tasks/${encodeURIComponent(taskId)}/events`,
      payload,
      signal,
    )
  }
}

export async function exchangeCodexPairing(input) {
  let response
  try {
    response = await (input.fetchImpl || globalThis.fetch)(
      `${input.baseUrl.replace(/\/+$/u, "")}/public/codex/pairings/exchange`,
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          pairingCode: input.pairingCode,
          deviceName: input.deviceName,
        }),
        signal: input.signal,
      },
    )
  } catch (error) {
    throw new BridgeHttpError(
      `无法连接 TapCanvas pairing endpoint：${errorMessage(error)}`,
      { code: "network_error" },
    )
  }
  const body = await parseResponse(response)
  if (!response.ok) {
    throw new BridgeHttpError(responseErrorMessage(body, response), {
      status: response.status,
      code:
        body && typeof body === "object" && typeof body.code === "string"
          ? body.code
          : "pairing_exchange_failed",
    })
  }
  if (
    !body ||
    typeof body !== "object" ||
    typeof body.apiKey !== "string" ||
    !body.apiKey
  ) {
    throw new BridgeHttpError("TapCanvas pairing 响应缺少 apiKey", {
      code: "pairing_response_invalid",
    })
  }
  return body
}

export async function uploadSourceArchive(input) {
  let response
  try {
    response = await (input.fetchImpl || globalThis.fetch)(input.uploadUrl, {
      method: "PUT",
      headers: {
        ...input.requiredHeaders,
        "content-length": String(input.archiveBytes),
      },
      body: createReadStream(input.archivePath),
      duplex: "half",
      signal: input.signal,
    })
  } catch (error) {
    throw new BridgeHttpError(
      `源码直传私有对象存储失败：${errorMessage(error)}`,
      { code: "source_upload_network_error" },
    )
  }
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 2_000)
    throw new BridgeHttpError(
      `源码直传私有对象存储失败（HTTP ${response.status}）：${detail}`,
      {
        status: response.status,
        code: "source_upload_failed",
      },
    )
  }
}
