#!/usr/bin/env node

import { randomUUID } from "node:crypto"
import { promises as fs } from "node:fs"
import os from "node:os"
import path from "node:path"
import {
  normalizeBridgeBaseUrl,
  readBridgeConfig,
  saveBridgeConfig,
} from "./bridge-config.mjs"
import {
  BridgeHttpClient,
  exchangeCodexPairing,
} from "./bridge-http-client.mjs"
import {
  probeCodexAppServer,
  readCodexVersion,
} from "./codex-app-server.mjs"
import { installCodexBridgeSkill } from "./codex-skill.mjs"
import {
  mcpUrl,
  upsertCodexToml,
} from "./config-writers.mjs"
import { runCodexWorker } from "./codex-worker.mjs"
import { authorizeCliAccess, runLegacyConnect } from "./legacy-connect.mjs"
import {
  installPlatformCli,
  preflightPlatformCliInstall,
} from "./platform-installer.mjs"
import { profileForApiBaseUrl } from "./platform-profile-config.mjs"
import {
  installPersistentBridgeService,
  preflightPersistentBridgeService,
  resolveExecutable,
} from "./service-installer.mjs"
import { errorMessage, runProcess, sleep } from "./process-utils.mjs"
import { isDockerAvailable, loadWorkspace } from "./workspace-config.mjs"
import { CONNECT_VERSION } from "./version.mjs"

function parseCommand(argv) {
  const command = String(argv[2] || "").trim()
  if (command === "pair" || command === "worker" || command === "install-cli") return command
  return "connect"
}

function parseNamedArgs(argv, startIndex) {
  const values = new Map()
  for (let index = startIndex; index < argv.length; index += 1) {
    const item = argv[index]
    if (!item.startsWith("--")) {
      throw new Error(`无法识别的参数：${item}`)
    }
    const equalIndex = item.indexOf("=")
    if (equalIndex > 2) {
      values.set(item.slice(2, equalIndex), item.slice(equalIndex + 1))
      continue
    }
    const name = item.slice(2)
    const value = argv[index + 1]
    if (!value || value.startsWith("--")) {
      throw new Error(`参数 --${name} 缺少值`)
    }
    values.set(name, value)
    index += 1
  }
  return values
}

function required(values, name) {
  const value = String(values.get(name) || "").trim()
  if (!value) throw new Error(`缺少 --${name}`)
  return value
}

async function readFileOrEmpty(file) {
  try {
    return await fs.readFile(file, "utf8")
  } catch (error) {
    if (error && typeof error === "object" && error.code === "ENOENT") return ""
    throw error
  }
}

async function writeCodexMcpConfig(baseUrl, apiKey) {
  const file = path.join(os.homedir(), ".codex", "config.toml")
  const content = upsertCodexToml(await readFileOrEmpty(file), {
    baseUrl,
    apiKey,
  })
  await fs.mkdir(path.dirname(file), { recursive: true, mode: 0o700 })
  const temporary = `${file}.${process.pid}.${randomUUID()}.tmp`
  await fs.writeFile(temporary, content, {
    encoding: "utf8",
    mode: 0o600,
    flag: "wx",
  })
  await fs.chmod(temporary, 0o600)
  await fs.rename(temporary, file)
  await fs.chmod(file, 0o600)
  return file
}

async function waitUntilBridgeOnline(client, bridgeId) {
  const deadline = Date.now() + 45_000
  let lastError = ""
  while (Date.now() < deadline) {
    try {
      const bridge = await client.bridgeStatus(bridgeId)
      if (bridge?.status === "online") return bridge
      lastError = `当前状态：${String(bridge?.status || "unknown")}`
    } catch (error) {
      lastError = errorMessage(error)
    }
    await sleep(1_000)
  }
  throw new Error(
    `常驻 Bridge 未在 45 秒内上线：${lastError || "没有收到状态"}`,
  )
}

async function preflightPair(values, environment) {
  const baseUrl = normalizeBridgeBaseUrl(required(values, "base-url"))
  const pairingCode = required(values, "pairing-code")
  const workspacePath = path.resolve(required(values, "workspace"))
  const codexBinary = await resolveExecutable(
    environment.CODEX_BINARY || "codex",
    { environment },
  )
  const nodeBinary = await resolveExecutable(process.execPath, { environment })
  let workspace = await loadWorkspace(workspacePath, {
    environment,
    dockerAvailable: false,
  })
  let dockerBinary = null
  if (workspace.config.localDocker) {
    try {
      dockerBinary = await resolveExecutable(
        environment.DOCKER_BINARY || "docker",
        { environment },
      )
      const available = await isDockerAvailable({
        dockerBinary,
        environment,
      })
      if (!available) dockerBinary = null
    } catch {
      dockerBinary = null
    }
    workspace = await loadWorkspace(workspacePath, {
      environment,
      dockerBinary,
      dockerAvailable: Boolean(dockerBinary),
    })
  }
  await readCodexVersion({ codexBinary })
  const platformCliPreflight = await preflightPlatformCliInstall({ environment })
  await preflightPersistentBridgeService({ environment })
  await probeCodexAppServer(
    { workspaceRoot: workspace.root },
    {
      codexBinary,
      environment,
      workerVersion: CONNECT_VERSION,
    },
  )
  return {
    baseUrl,
    pairingCode,
    workspace,
    codexBinary,
    dockerBinary,
    nodeBinary,
    platformCliPreflight,
  }
}

async function verifyInstalledPlatformCli(installed, environment) {
  const doctor = await runProcess(
    process.execPath,
    [installed.runtimeEntrypoint, "doctor", "--profile", installed.profile, "--json"],
    {
      env: environment,
      timeoutMs: 30_000,
    },
  )
  if (doctor.exitCode !== 0 || doctor.timedOut) {
    const reason = doctor.stderr.trim() || doctor.stdout.trim() || "没有返回诊断信息"
    throw new Error(`TapCanvas CLI 安装后 doctor 失败：${reason}`)
  }
  let doctorResult
  try {
    doctorResult = JSON.parse(doctor.stdout)
  } catch {
    throw new Error("TapCanvas CLI 安装后 doctor 未返回合法 JSON")
  }
  if (!doctorResult || typeof doctorResult !== "object" || doctorResult.ok !== true) {
    throw new Error("TapCanvas CLI 安装后 doctor 未确认安装成功")
  }
  return doctorResult
}

async function runPair(argv) {
  const environment = process.env
  const values = parseNamedArgs(argv, 3)
  process.stdout.write("正在检查 Codex、workspace 与常驻服务环境…\n")
  const preflight = await preflightPair(values, environment)
  process.stdout.write("正在使用画布的一次性配对码建立专用连接…\n")
  const pairing = await exchangeCodexPairing({
    baseUrl: preflight.baseUrl,
    pairingCode: preflight.pairingCode,
    deviceName: os.hostname(),
  })
  const platformCli = await installPlatformCli(
    {
      profile: profileForApiBaseUrl(preflight.baseUrl),
      apiBaseUrl: preflight.baseUrl,
      apiKey: pairing.apiKey,
    },
    { environment, preflight: preflight.platformCliPreflight },
  )
  await verifyInstalledPlatformCli(platformCli, environment)
  const codexConfigFile = await writeCodexMcpConfig(
    preflight.baseUrl,
    pairing.apiKey,
  )
  const skillPath = await installCodexBridgeSkill({ environment })
  const saved = await saveBridgeConfig(
    {
      name: os.hostname(),
      baseUrl: preflight.baseUrl,
      apiKey: pairing.apiKey,
      codexBinary: preflight.codexBinary,
      dockerBinary: preflight.dockerBinary,
      workspacePaths: [preflight.workspace.root],
    },
    { environment },
  )
  const service = await installPersistentBridgeService(
    { nodeBinary: preflight.nodeBinary },
    {
      environment: {
        ...environment,
        PATH: [
          path.dirname(platformCli.commandPath),
          String(environment.PATH || ""),
        ].filter(Boolean).join(path.delimiter),
      },
    },
  )
  const client = new BridgeHttpClient({
    baseUrl: preflight.baseUrl,
    apiKey: pairing.apiKey,
  })
  await waitUntilBridgeOnline(client, saved.config.bridgeId)
  process.stdout.write(
    [
      "",
      "已连接。以后直接回到 TapCanvas 画布选择 Codex 并派发任务即可。",
      `- Workspace：${preflight.workspace.config.label} (${preflight.workspace.config.id})`,
      `- Codex MCP：${codexConfigFile}`,
      `- Codex Skill：${skillPath}`,
      `- TapCanvas CLI：${platformCli.commandPath}`,
      `- 常驻服务：${service.service.kind}`,
      `- Bridge 配置：${saved.file}`,
      `- MCP 地址：${mcpUrl(preflight.baseUrl)}`,
      preflight.workspace.config.localDocker && !preflight.dockerBinary
        ? "- 本机 Docker：workspace 已配置，但 Docker 当前不可用；画布不会提供本机 fallback 审批。"
        : "- 本机 Docker：仅在远程基础设施故障且画布明确批准后使用。",
      "",
    ].join("\n"),
  )
}

async function runWorker(argv) {
  const values = parseNamedArgs(argv, 3)
  const configOverride = String(values.get("config") || "").trim()
  const environment = configOverride
    ? { ...process.env, TAPCANVAS_BRIDGE_CONFIG: path.resolve(configOverride) }
    : process.env
  await readBridgeConfig({ environment })
  await runCodexWorker({ environment })
}

async function runInstallCli(argv) {
  const environment = process.env
  const values = parseNamedArgs(argv, 3)
  const baseUrl = normalizeBridgeBaseUrl(required(values, "base-url"))
  process.stdout.write("正在检查 TapCanvas CLI、Codex Skill 与本机命令路径…\n")
  const preflight = await preflightPlatformCliInstall({ environment })
  process.stdout.write("检查通过。请在浏览器中确认 CLI & SKILL 授权。\n")
  const authorization = await authorizeCliAccess({
    baseUrl,
    client: "tapcanvas-cli",
    environment,
  })
  process.stdout.write("正在安装 tapcanvas 命令和官方 TapCanvas API Skill…\n")
  const installed = await installPlatformCli(
    {
      profile: profileForApiBaseUrl(authorization.apiBaseUrl),
      apiBaseUrl: authorization.apiBaseUrl,
      apiKey: authorization.apiKey,
    },
    { environment, preflight },
  )
  await verifyInstalledPlatformCli(installed, environment)
  process.stdout.write(
    [
      "",
      "CLI & SKILL 已安装。",
      `- CLI 版本：${installed.cliVersion}`,
      `- 命令：${installed.commandPath}`,
      `- 配置：${installed.configPath}`,
      `- Codex Skill：${installed.skillPath}`,
      installed.commandAvailableOnPath
        ? "- PATH：已可直接运行 tapcanvas"
        : `- PATH：请把 ${path.dirname(installed.commandPath)} 加入 PATH`,
      "",
      `验证命令：${installed.commandPath} doctor --profile ${installed.profile} --json`,
      "",
    ].join("\n"),
  )
}

function printHelp() {
  process.stdout.write(
    [
      `tapcanvas-connect ${CONNECT_VERSION}`,
      "",
      "画布首次连接（这条命令由本地 Codex 根据画布复制内容执行）：",
      "  tapcanvas-connect pair --base-url <API 地址> --pairing-code <一次性码> --workspace <目录>",
      "",
      "常驻 Worker（由系统服务自动启动）：",
      "  tapcanvas-connect worker [--config <配置文件>]",
      "",
      "安装 TapCanvas 平台 CLI 与 Codex Skill：",
      "  tapcanvas-connect install-cli --base-url <TapCanvas 地址>",
      "",
      "原有 MCP 客户端接入：",
      "  tapcanvas-connect --base-url <TapCanvas 地址> [--client codex|claude|cursor|all]",
      "",
    ].join("\n"),
  )
}

async function main() {
  if (process.argv.includes("--help") || process.argv.includes("-h")) {
    printHelp()
    return
  }
  const command = parseCommand(process.argv)
  if (command === "pair") {
    await runPair(process.argv)
    return
  }
  if (command === "worker") {
    await runWorker(process.argv)
    return
  }
  if (command === "install-cli") {
    await runInstallCli(process.argv)
    return
  }
  await runLegacyConnect(process.argv)
}

main().catch((error) => {
  process.stderr.write(`\n连接失败：${errorMessage(error)}\n`)
  process.exitCode = 1
})
