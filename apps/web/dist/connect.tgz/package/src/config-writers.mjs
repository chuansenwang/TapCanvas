// 纯函数 config writers：把 TapCanvas MCP server 合并进各客户端配置（不破坏既有条目）。
// 全部「输入旧内容 → 输出新内容」，无 IO，便于单测；真正读写文件在 cli.mjs。

const SERVER_NAME = "tapcanvas"

/** MCP server 路径。 */
export function mcpUrl(baseUrl) {
  return `${String(baseUrl).replace(/\/+$/, "")}/public/mcp`
}

/**
 * 合并 Claude Code 的 `.mcp.json`（项目级）/ mcpServers 容器。
 * @param existing 解析后的旧对象（无则传 null/{}）
 * @returns 新对象（含 mcpServers.tapcanvas）
 */
export function mergeClaudeMcpJson(existing, { baseUrl, apiKey }) {
  const root = existing && typeof existing === "object" ? { ...existing } : {}
  const servers = root.mcpServers && typeof root.mcpServers === "object" ? { ...root.mcpServers } : {}
  servers[SERVER_NAME] = {
    type: "http",
    url: mcpUrl(baseUrl),
    headers: { Authorization: `Bearer ${apiKey}` },
  }
  root.mcpServers = servers
  return root
}

/**
 * 合并 Cursor 的 `~/.cursor/mcp.json`。Cursor 的 server 形状与 Claude 类似（url + headers）。
 */
export function mergeCursorMcpJson(existing, { baseUrl, apiKey }) {
  const root = existing && typeof existing === "object" ? { ...existing } : {}
  const servers = root.mcpServers && typeof root.mcpServers === "object" ? { ...root.mcpServers } : {}
  servers[SERVER_NAME] = {
    url: mcpUrl(baseUrl),
    headers: { Authorization: `Bearer ${apiKey}` },
  }
  root.mcpServers = servers
  return root
}

/** 我们写进 config.toml 的 TapCanvas 块（inline http_headers，Key 直接落文件 → 全自动）。 */
export function buildCodexTomlBlock({ baseUrl, apiKey }) {
  return [
    `[mcp_servers.${SERVER_NAME}]`,
    `url = "${mcpUrl(baseUrl)}"`,
    `http_headers = { "Authorization" = "Bearer ${apiKey}" }`,
  ].join("\n")
}

/**
 * upsert Codex 的 `~/.codex/config.toml`：若已有 `[mcp_servers.tapcanvas]` 块则整块替换，否则追加。
 * 用「下一个顶层 [section] 或文件结尾」界定块边界，避免误删后续配置。纯文本操作、可单测。
 */
export function upsertCodexToml(existingText, { baseUrl, apiKey }) {
  const block = buildCodexTomlBlock({ baseUrl, apiKey })
  const text = typeof existingText === "string" ? existingText : ""
  const header = `[mcp_servers.${SERVER_NAME}]`
  const startIdx = text.indexOf(header)
  if (startIdx === -1) {
    const sep = text.trim().length ? (text.endsWith("\n") ? "\n" : "\n\n") : ""
    return `${text}${sep}${block}\n`
  }
  // 找块结尾：从 header 之后的下一行起，遇到下一个顶层 [..] 或文件尾。
  const after = text.slice(startIdx + header.length)
  const nextSection = after.search(/\n\s*\[/)
  const endIdx = nextSection === -1 ? text.length : startIdx + header.length + nextSection
  return `${text.slice(0, startIdx)}${block}${text.slice(endIdx)}`
}

/** 解析 JSON 文本为对象；空/坏内容回 null（让 merge 当作全新）。 */
export function safeParseJson(text) {
  if (typeof text !== "string" || !text.trim()) return null
  try {
    const v = JSON.parse(text)
    return v && typeof v === "object" ? v : null
  } catch {
    return null
  }
}

export const CONNECT_SERVER_NAME = SERVER_NAME
