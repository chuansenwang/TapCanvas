#!/usr/bin/env node
// @tapcanvas/connect — 一行把 TapCanvas（小T）接入 Claude Code / Codex CLI / Cursor。
//
// 流程（OAuth loopback 套路，同 gh / gcloud）：
//   ① 起本机 loopback http server（随机端口）
//   ② 开浏览器到 <BASE>/connect/cli?port=..&state=..&client=..  （登录态下点「授权并连接」铸 Key）
//   ③ 浏览器把 Key 重定向回 http://127.0.0.1:<port>/callback?key=..&state=..
//   ④ 收到 Key → 写好所选客户端的 MCP 配置 → 完成
//
// 用法：
//   npx @tapcanvas/connect --base-url https://你的TapCanvas域名 [--client claude|codex|cursor|all]

import http from "node:http"
import { spawn } from "node:child_process"
import { promises as fs } from "node:fs"
import os from "node:os"
import path from "node:path"
import {
  mergeClaudeMcpJson,
  mergeCursorMcpJson,
  upsertCodexToml,
  safeParseJson,
  mcpUrl,
} from "./config-writers.mjs"

const CLIENTS = ["claude", "codex", "cursor"]

function parseArgs(argv) {
  const out = { client: "all", baseUrl: "" }
  for (let i = 2; i < argv.length; i += 1) {
    const a = argv[i]
    if (a === "--base-url" || a === "-b") out.baseUrl = argv[++i] || ""
    else if (a === "--client" || a === "-c") out.client = (argv[++i] || "all").toLowerCase()
    else if (a === "--help" || a === "-h") out.help = true
    else if (a.startsWith("--base-url=")) out.baseUrl = a.slice("--base-url=".length)
    else if (a.startsWith("--client=")) out.client = a.slice("--client=".length).toLowerCase()
  }
  return out
}

function printHelp() {
  process.stdout.write(
    [
      "tapcanvas-connect — 把 TapCanvas 接入你的 AI 客户端",
      "",
      "用法：",
      "  npx @tapcanvas/connect --base-url <TapCanvas 域名> [--client claude|codex|cursor|all]",
      "",
      "示例：",
      "  npx @tapcanvas/connect --base-url https://app.tapcanvas.ai --client claude",
      "",
    ].join("\n"),
  )
}

function openBrowser(url, environment = process.env) {
  if (environment.TAPCANVAS_CONNECT_NO_BROWSER === "1") return // 测试/无头环境跳过
  const platform = process.platform
  const cmd = platform === "darwin" ? "open" : platform === "win32" ? "cmd" : "xdg-open"
  const args = platform === "win32" ? ["/c", "start", "", url] : [url]
  try {
    const child = spawn(cmd, args, { stdio: "ignore", detached: true })
    child.on("error", () => {})
    child.unref()
  } catch {
    /* 打不开就让用户手动点 */
  }
}

export async function authorizeCliAccess({
  baseUrl,
  client = "all",
  deviceName = os.hostname(),
  environment = process.env,
}) {
  const normalizedBaseUrl = String(baseUrl || "").replace(/\/+$/, "")
  if (!normalizedBaseUrl) throw new Error("缺少 TapCanvas 站点地址")

  const state = randomState()
  const { port, done } = await startLoopback({ state })
  const verifyUrl =
    `${normalizedBaseUrl}/connect/cli?port=${port}&state=${state}` +
    `&client=${encodeURIComponent(client)}&name=${encodeURIComponent(deviceName)}`

  process.stdout.write(`\n🔗 正在打开浏览器完成授权…\n如果没自动打开，手动访问：\n  ${verifyUrl}\n\n`)
  openBrowser(verifyUrl, environment)

  const { key, apiBaseUrl } = await done
  return {
    apiKey: key,
    apiBaseUrl: String(apiBaseUrl || normalizedBaseUrl).replace(/\/+$/, ""),
  }
}

function randomState() {
  return Array.from({ length: 16 }, () => Math.floor(Math.random() * 36).toString(36)).join("")
}

const HTML_DONE = `<!doctype html><meta charset="utf-8"><body style="font-family:-apple-system,sans-serif;background:#0f1115;color:#fff;display:flex;justify-content:center;align-items:center;height:100vh"><div style="text-align:center"><h2>✅ 已连接</h2><p style="color:#98a2b3">配置已写好，可以关闭本页回到终端了。</p></div></body>`
const HTML_ERR = `<!doctype html><meta charset="utf-8"><body style="font-family:-apple-system,sans-serif;background:#0f1115;color:#fff;display:flex;justify-content:center;align-items:center;height:100vh"><div style="text-align:center"><h2>⚠️ 连接未完成</h2><p style="color:#98a2b3">可关闭本页，回终端重试。</p></div></body>`

/** 起 server 并返回 { port, done }，done 是等回调的 promise。 */
function startLoopback({ state }) {
  return new Promise((resolveOuter, rejectOuter) => {
    let settled = false
    const server = http.createServer((req, res) => {
      const u = new URL(req.url, "http://127.0.0.1")
      if (u.pathname !== "/callback") {
        res.writeHead(404).end()
        return
      }
      const gotState = u.searchParams.get("state") || ""
      const key = u.searchParams.get("key") || ""
      const error = u.searchParams.get("error") || ""
      // 授权页透传的 API 域（前后端分域时 MCP 端点应写它，而非连接服务的站点域）。
      const apiBaseUrl = u.searchParams.get("apiBaseUrl") || ""
      const ok = !error && key && gotState === state
      res.writeHead(200, { "content-type": "text/html; charset=utf-8" })
      res.end(ok ? HTML_DONE : HTML_ERR)
      server.close()
      if (settled) return
      settled = true
      if (error) rejectInner(new Error(`授权被拒绝或失败：${error}`))
      else if (!key) rejectInner(new Error("未收到 Key"))
      else if (gotState !== state) rejectInner(new Error("state 不匹配（疑似 CSRF），已中止"))
      else resolveInner({ key, apiBaseUrl })
    })
    let resolveInner, rejectInner
    const done = new Promise((res, rej) => {
      resolveInner = res
      rejectInner = rej
    })
    const timer = setTimeout(() => {
      if (settled) return
      settled = true
      server.close()
      rejectInner(new Error("等待授权超时（5 分钟）"))
    }, 5 * 60 * 1000)
    done.finally(() => clearTimeout(timer)).catch(() => {})
    server.on("error", rejectOuter)
    server.listen(0, "127.0.0.1", () => {
      resolveOuter({ port: server.address().port, done })
    })
  })
}

async function readFileOrEmpty(p) {
  try {
    return await fs.readFile(p, "utf-8")
  } catch {
    return ""
  }
}

async function writeFileMkdir(p, content) {
  await fs.mkdir(path.dirname(p), { recursive: true })
  await fs.writeFile(p, content, "utf-8")
}

/** 写各客户端配置。返回安装结果说明数组。 */
async function installConfigs({ clients, baseUrl, apiKey }) {
  const home = os.homedir()
  const results = []

  if (clients.includes("claude")) {
    // 优先用官方 CLI（正确维护 ~/.claude.json）；没有 claude 命令则写项目级 .mcp.json。
    const ran = await tryRun("claude", [
      "mcp",
      "add",
      "--transport",
      "http",
      "tapcanvas",
      mcpUrl(baseUrl),
      "--header",
      `Authorization: Bearer ${apiKey}`,
    ])
    if (ran.ok) {
      results.push("✅ Claude Code：已通过 `claude mcp add` 安装（local scope）")
    } else {
      const file = path.resolve(process.cwd(), ".mcp.json")
      const merged = mergeClaudeMcpJson(safeParseJson(await readFileOrEmpty(file)), { baseUrl, apiKey })
      await writeFileMkdir(file, JSON.stringify(merged, null, 2) + "\n")
      results.push(`✅ Claude Code：未检测到 claude 命令，已写项目级配置 ${file}（在该项目打开 Claude Code 会提示批准）`)
    }
  }

  if (clients.includes("cursor")) {
    const file = path.join(home, ".cursor", "mcp.json")
    const merged = mergeCursorMcpJson(safeParseJson(await readFileOrEmpty(file)), { baseUrl, apiKey })
    await writeFileMkdir(file, JSON.stringify(merged, null, 2) + "\n")
    results.push(`✅ Cursor：已写入 ${file}`)
  }

  if (clients.includes("codex")) {
    const file = path.join(home, ".codex", "config.toml")
    const merged = upsertCodexToml(await readFileOrEmpty(file), { baseUrl, apiKey })
    await writeFileMkdir(file, merged)
    results.push(`✅ Codex CLI：已写入 ${file}`)
  }

  return results
}

/** 尝试跑一个命令；命令不存在/失败回 {ok:false}。 */
function tryRun(cmd, args) {
  return new Promise((resolve) => {
    let child
    try {
      child = spawn(cmd, args, { stdio: "ignore" })
    } catch {
      resolve({ ok: false })
      return
    }
    child.on("error", () => resolve({ ok: false }))
    child.on("exit", (code) => resolve({ ok: code === 0 }))
  })
}

export async function runLegacyConnect(argv = process.argv) {
  const args = parseArgs(argv)
  if (args.help) {
    printHelp()
    return
  }
  const baseUrl = String(args.baseUrl || "").replace(/\/+$/, "")
  if (!baseUrl) {
    process.stderr.write("缺少 --base-url <TapCanvas 域名>。例：--base-url https://app.tapcanvas.ai\n")
    process.exitCode = 1
    return
  }
  const client = CLIENTS.includes(args.client) ? args.client : "all"
  const clients = client === "all" ? CLIENTS : [client]

  let authorization
  try {
    authorization = await authorizeCliAccess({
      baseUrl,
      client,
      environment: process.env,
    })
  } catch (e) {
    process.stderr.write(`\n❌ ${e?.message || e}\n`)
    process.exitCode = 1
    return
  }

  process.stdout.write("🔑 已获取接入密钥，正在写入客户端配置…\n")
  // MCP / A2A 端点基址：优先用授权页透传的 API 域（前后端分域时与站点域不同），
  // 否则回落 --base-url（同域部署时二者一致，行为不变）。
  const results = await installConfigs({
    clients,
    baseUrl: authorization.apiBaseUrl,
    apiKey: authorization.apiKey,
  })
  process.stdout.write("\n" + results.join("\n") + "\n")
  process.stdout.write("\n🎉 完成！重启对应客户端即可把 TapCanvas（小T）当子 agent 调用。\n")
}
