export const CONNECT_VERSION = "0.8.1"
export const PLATFORM_CLI_VERSION = "0.4.6"
