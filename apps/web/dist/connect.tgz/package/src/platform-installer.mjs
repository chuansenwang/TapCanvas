import { createHash, randomUUID } from "node:crypto"
import { constants as fsConstants, promises as fs } from "node:fs"
import os from "node:os"
import path from "node:path"
import { fileURLToPath } from "node:url"
import {
  createTapCanvasConfigWithProfile,
  normalizeTapCanvasProfile,
} from "./platform-profile-config.mjs"
import { PLATFORM_CLI_VERSION } from "./version.mjs"

const INSTALL_MARKER_VERSION = 1

function packageRoot() {
  return path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..")
}

function installRoot(environment = process.env) {
  return environment.TAPCANVAS_HOME
    ? path.resolve(environment.TAPCANVAS_HOME)
    : path.join(os.homedir(), ".tapcanvas")
}

function codexRoot(environment = process.env) {
  return environment.CODEX_HOME
    ? path.resolve(environment.CODEX_HOME)
    : path.join(os.homedir(), ".codex")
}

async function pathExists(file) {
  try {
    await fs.access(file)
    return true
  } catch {
    return false
  }
}

async function readJsonIfExists(file) {
  try {
    return JSON.parse(await fs.readFile(file, "utf8"))
  } catch (error) {
    if (error && typeof error === "object" && error.code === "ENOENT") return null
    throw new Error(`无法读取 TapCanvas CLI 安装记录：${file}`)
  }
}

async function atomicWrite(file, content, mode) {
  await fs.mkdir(path.dirname(file), { recursive: true, mode: 0o700 })
  const temporary = `${file}.${process.pid}.${randomUUID()}.tmp`
  await fs.writeFile(temporary, content, {
    encoding: "utf8",
    mode,
    flag: "wx",
  })
  await fs.chmod(temporary, mode)
  await fs.rename(temporary, file)
  await fs.chmod(file, mode)
}

function sha256(content) {
  return createHash("sha256").update(content).digest("hex")
}

function shellQuote(value) {
  return `'${String(value).replaceAll("'", `'\\''`)}'`
}

function resolvePaths(environment = process.env) {
  const root = installRoot(environment)
  const runtimeRoot = path.join(root, "cli", PLATFORM_CLI_VERSION)
  const commandDirectory = environment.TAPCANVAS_COMMAND_DIR
    ? path.resolve(environment.TAPCANVAS_COMMAND_DIR)
    : path.join(os.homedir(), ".local", "bin")
  return {
    root,
    runtimeRoot,
    runtimeEntrypoint: path.join(runtimeRoot, "src", "platform-cli.mjs"),
    configPath: path.join(root, "config.json"),
    markerPath: path.join(root, "cli-install.json"),
    shimPath: path.join(root, "bin", "tapcanvas"),
    commandPath: path.join(commandDirectory, "tapcanvas"),
    skillPath: path.join(codexRoot(environment), "skills", "tapcanvas-api", "SKILL.md"),
  }
}

async function verifyManagedFile(file, expectedManagedPath, label) {
  if (!(await pathExists(file))) return
  if (path.resolve(file) !== path.resolve(expectedManagedPath)) {
    throw new Error(`${label}路径与已有 TapCanvas CLI 安装记录不一致：${file}`)
  }
}

async function verifyManagedContent(file, expectedHash, label) {
  if (!(await pathExists(file))) return
  if (typeof expectedHash !== "string" || expectedHash.length !== 64) {
    throw new Error(`已有 TapCanvas CLI 安装记录缺少 ${label} 完整性信息`)
  }
  const currentHash = sha256(await fs.readFile(file))
  if (currentHash !== expectedHash) {
    throw new Error(`${label}在安装后已被修改；不会覆盖：${file}`)
  }
}

async function verifyCommandPath(paths) {
  if (!(await pathExists(paths.commandPath))) return
  const stat = await fs.lstat(paths.commandPath)
  if (stat.isSymbolicLink()) {
    const target = await fs.readlink(paths.commandPath)
    const resolvedTarget = path.resolve(path.dirname(paths.commandPath), target)
    if (resolvedTarget === path.resolve(paths.shimPath)) return
  }
  throw new Error(
    `命令 ${paths.commandPath} 已存在且不属于 TapCanvas CLI；不会覆盖，请先处理命令冲突`,
  )
}

export async function preflightPlatformCliInstall(options = {}) {
  const environment = options.environment || process.env
  const paths = resolvePaths(environment)
  const root = options.packageRoot || packageRoot()
  const sourceEntrypoint = path.join(root, "src", "platform-cli.mjs")
  const sourceProfileConfig = path.join(root, "src", "platform-profile-config.mjs")
  const sourceSkill = path.join(root, "skill", "tapcanvas-api", "SKILL.md")
  const sourceCall = path.join(root, "skill", "tapcanvas-api", "scripts", "call.mjs")
  const sourceSubscribe = path.join(root, "skill", "tapcanvas-api", "scripts", "subscribe.mjs")
  const sourceProfileResolver = path.join(root, "skill", "tapcanvas-api", "scripts", "profile-config.mjs")

  for (const source of [
    sourceEntrypoint,
    sourceProfileConfig,
    sourceSkill,
    sourceCall,
    sourceSubscribe,
    sourceProfileResolver,
  ]) {
    const stat = await fs.stat(source).catch(() => null)
    if (!stat?.isFile()) throw new Error(`TapCanvas CLI 安装包不完整：${source}`)
  }

  const marker = await readJsonIfExists(paths.markerPath)
  if (!marker) {
    for (const [file, label] of [
      [paths.configPath, "配置文件"],
      [paths.shimPath, "命令入口"],
      [paths.skillPath, "Codex Skill"],
    ]) {
      if (await pathExists(file)) {
        throw new Error(`${label}已存在但没有 TapCanvas CLI 安装记录；不会覆盖：${file}`)
      }
    }
  } else {
    if (marker.version !== INSTALL_MARKER_VERSION) {
      throw new Error(`无法识别已有 TapCanvas CLI 安装记录版本：${paths.markerPath}`)
    }
    await verifyManagedFile(paths.configPath, marker.configPath, "配置文件")
    await verifyManagedFile(paths.shimPath, marker.shimPath, "命令入口")
    await verifyManagedFile(paths.skillPath, marker.skillPath, "Codex Skill")
    await verifyManagedContent(paths.shimPath, marker.shimSha256, "命令入口")
    await verifyManagedContent(paths.skillPath, marker.skillSha256, "Codex Skill")
  }
  await verifyCommandPath(paths)

  return {
    environment,
    packageRoot: root,
    paths,
    marker,
    sourceSkillContent: await fs.readFile(sourceSkill, "utf8"),
  }
}

async function installRuntime(preflight) {
  const { runtimeRoot } = preflight.paths
  if (await pathExists(runtimeRoot)) {
    const marker = await readJsonIfExists(path.join(runtimeRoot, "runtime.json"))
    if (marker?.version !== PLATFORM_CLI_VERSION) {
      throw new Error(`TapCanvas CLI runtime 版本标记不一致：${runtimeRoot}`)
    }
    return
  }

  await fs.mkdir(path.dirname(runtimeRoot), { recursive: true, mode: 0o700 })
  const temporary = `${runtimeRoot}.${process.pid}.${randomUUID()}.tmp`
  try {
    await fs.mkdir(path.join(temporary, "src"), { recursive: true, mode: 0o700 })
    await fs.copyFile(
      path.join(preflight.packageRoot, "src", "platform-cli.mjs"),
      path.join(temporary, "src", "platform-cli.mjs"),
    )
    await fs.copyFile(
      path.join(preflight.packageRoot, "src", "version.mjs"),
      path.join(temporary, "src", "version.mjs"),
    )
    await fs.copyFile(
      path.join(preflight.packageRoot, "src", "platform-profile-config.mjs"),
      path.join(temporary, "src", "platform-profile-config.mjs"),
    )
    await fs.cp(
      path.join(preflight.packageRoot, "skill"),
      path.join(temporary, "skill"),
      { recursive: true, errorOnExist: true, force: false },
    )
    await fs.writeFile(
      path.join(temporary, "runtime.json"),
      `${JSON.stringify({ version: PLATFORM_CLI_VERSION }, null, 2)}\n`,
      { encoding: "utf8", mode: 0o600 },
    )
    await fs.rename(temporary, runtimeRoot)
  } catch (error) {
    await fs.rm(temporary, { recursive: true, force: true })
    throw error
  }
}

async function upsertCommandLink(paths) {
  await fs.mkdir(path.dirname(paths.commandPath), { recursive: true, mode: 0o700 })
  if (await pathExists(paths.commandPath)) {
    const stat = await fs.lstat(paths.commandPath)
    if (stat.isSymbolicLink()) await fs.unlink(paths.commandPath)
  }
  await fs.symlink(paths.shimPath, paths.commandPath)
}

export async function installPlatformCli(input, options = {}) {
  const profile = normalizeTapCanvasProfile(input.profile)

  const preflight = options.preflight || await preflightPlatformCliInstall(options)
  const { paths, environment } = preflight
  await installRuntime(preflight)

  const currentConfig = preflight.marker
    ? await readJsonIfExists(paths.configPath)
    : null
  const config = createTapCanvasConfigWithProfile({
    current: currentConfig,
    file: paths.configPath,
    profile,
    apiBaseUrl: input.apiBaseUrl,
    apiKey: input.apiKey,
  })
  const configContent = `${JSON.stringify(config, null, 2)}\n`
  await atomicWrite(paths.configPath, configContent, 0o600)
  await atomicWrite(paths.skillPath, preflight.sourceSkillContent, 0o600)

  const nodeBinary = await fs.realpath(process.execPath)
  const shim = `#!/bin/sh\nexec ${shellQuote(nodeBinary)} ${shellQuote(paths.runtimeEntrypoint)} "$@"\n`
  await atomicWrite(paths.shimPath, shim, 0o700)
  await fs.access(paths.shimPath, fsConstants.X_OK)
  await upsertCommandLink(paths)

  const marker = {
    version: INSTALL_MARKER_VERSION,
    cliVersion: PLATFORM_CLI_VERSION,
    installedAt: new Date().toISOString(),
    runtimeRoot: paths.runtimeRoot,
    configPath: paths.configPath,
    shimPath: paths.shimPath,
    commandPath: paths.commandPath,
    skillPath: paths.skillPath,
    configSha256: sha256(configContent),
    shimSha256: sha256(shim),
    skillSha256: sha256(preflight.sourceSkillContent),
  }
  await atomicWrite(paths.markerPath, `${JSON.stringify(marker, null, 2)}\n`, 0o600)

  const pathEntries = String(environment.PATH || "").split(path.delimiter)
  return {
    ...paths,
    cliVersion: PLATFORM_CLI_VERSION,
    profile,
    commandAvailableOnPath: pathEntries.includes(path.dirname(paths.commandPath)),
  }
}
