const RESPONSE_OUTCOMES = new Map([
  [
    "needs_input",
    {
      state: "awaiting_user_input",
      code: "codex_turn_needs_input",
    },
  ],
  [
    "response_only",
    {
      state: "succeeded",
      code: "codex_turn_response_only",
    },
  ],
])

export function classifyCodexTurnResult(result) {
  if (result.status !== "completed") {
    return {
      kind: "failure",
      code: "codex_turn_not_completed",
      message: `Codex turn 以 ${result.status} 结束：${result.summary}`,
    }
  }

  if (result.outcome === "failed") {
    return {
      kind: "failure",
      code: "codex_turn_explicit_failure",
      message: result.summary,
    }
  }

  const responseDisposition = RESPONSE_OUTCOMES.get(result.outcome)
  if (responseDisposition) {
    if (result.changedFiles.length > 0) {
      return {
        kind: "failure",
        code: "codex_turn_outcome_inconsistent",
        message:
          "Codex 声明本回合没有 workspace 交付，但 App Server 记录到真实文件变更；为避免隐藏副作用，任务已失败。",
      }
    }
    return {
      kind: "response",
      ...responseDisposition,
      message: result.summary,
    }
  }

  if (result.outcome !== "workspace_changed") {
    return {
      kind: "failure",
      code: "codex_turn_outcome_unsupported",
      message: `Codex 返回了不受支持的 turn outcome：${String(result.outcome)}`,
    }
  }

  if (result.changedFiles.length === 0) {
    return {
      kind: "failure",
      code: "codex_turn_changed_no_files",
      message:
        "Codex 声明 workspace_changed，但 App Server 没有记录到真实文件变更。",
    }
  }

  return { kind: "workspace_changed" }
}
